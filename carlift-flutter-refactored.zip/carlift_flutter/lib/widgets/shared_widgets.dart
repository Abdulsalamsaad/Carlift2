import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../data/models/models.dart';
import '../state/providers.dart';
import '../l10n/app_localizations.dart';

Color hexToColor(String hex) {
  final h = hex.replaceAll('#', '');
  return Color(int.parse('FF$h', radix: 16));
}

class RouteBadge extends StatelessWidget {
  final String from;
  final String to;
  final bool light;
  final double fontSize;
  const RouteBadge({super.key, required this.from, required this.to, this.light = false, this.fontSize = 16});

  @override
  Widget build(BuildContext context) {
    final textColor = light ? Colors.white : AppColors.navy;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(zoneCode(from), style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w800, fontSize: fontSize, color: textColor, letterSpacing: 1)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: Row(children: [
            Container(width: 10, height: 1, color: AppColors.gold),
            Icon(Icons.directions_bus_rounded, size: fontSize * 0.75, color: AppColors.gold),
            Container(width: 10, height: 1, color: AppColors.gold),
          ]),
        ),
        Text(zoneCode(to), style: TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w800, fontSize: fontSize, color: textColor, letterSpacing: 1)),
      ],
    );
  }
}

class SelectPill extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const SelectPill({super.key, required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.navy : Colors.white,
          border: Border.all(color: active ? AppColors.navy : AppColors.line),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.muted)),
      ),
    );
  }
}

class AppField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final String? error;
  final TextInputType? keyboardType;
  final bool obscure;
  final int? maxLength;
  const AppField({super.key, required this.label, required this.controller, this.error, this.keyboardType, this.obscure = false, this.maxLength});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
        const SizedBox(height: 4),
        TextField(
          controller: controller, keyboardType: keyboardType, obscureText: obscure, maxLength: maxLength,
          decoration: InputDecoration(counterText: '', errorText: error),
        ),
      ],
    );
  }
}

/// Ad banner tied to a placement zone — pulls from AdsProvider (mock or live
/// GET /api/v1/ads/active), tracks a click through the provider, and hides
/// itself entirely if no active campaign exists for that zone (never a dead
/// placeholder box).
class AdBannerWidget extends StatefulWidget {
  final String placementZone;
  const AdBannerWidget({super.key, required this.placementZone});

  @override
  State<AdBannerWidget> createState() => _AdBannerWidgetState();
}

class _AdBannerWidgetState extends State<AdBannerWidget> {
  AdBanner? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    context.read<AdsProvider>().forZone(widget.placementZone).then((ad) {
      if (mounted) setState(() { _ad = ad; _loaded = true; });
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad == null) return const SizedBox.shrink();
    final t = AppLocalizations.of(context)!;
    final ad = _ad!;
    final colors = ad.gradientHex.map(hexToColor).toList();
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => context.read<AdsProvider>().trackClick(ad.id),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(4)),
                    child: Text('${t.adSponsored} · ${ad.sponsor}', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.white)),
                  ),
                  const SizedBox(height: 6),
                  Text(ad.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14)),
                  const SizedBox(height: 6),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(t.adLearnMore, style: const TextStyle(color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 3),
                    const Icon(Icons.open_in_new_rounded, size: 11, color: AppColors.gold),
                  ]),
                ],
              ),
            ),
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 22),
            ),
          ],
        ),
      ),
    );
  }
}

/// Scrolling marquee/ticker for corporate-partner promos on the home page and
/// key transition screens (search results, checkout). Pure CustomPaint-free
/// implementation using an AnimationController + Transform for broad
/// Android/iOS/Web compatibility.
class MarqueeTicker extends StatefulWidget {
  final String text;
  const MarqueeTicker({super.key, required this.text});

  @override
  State<MarqueeTicker> createState() => _MarqueeTickerState();
}

class _MarqueeTickerState extends State<MarqueeTicker> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 22))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      color: AppColors.navy,
      child: ClipRect(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return LayoutBuilder(builder: (context, constraints) {
              final textPainter = TextPainter(
                text: TextSpan(text: widget.text, style: const TextStyle(fontSize: 12, color: Colors.white)),
                textDirection: Directionality.of(context),
              )..layout();
              final textWidth = textPainter.width + 60;
              final offset = -(_controller.value * textWidth);
              return Stack(
                children: [
                  Positioned(
                    left: offset + textWidth,
                    top: 8,
                    child: _tickerText(),
                  ),
                  Positioned(left: offset, top: 8, child: _tickerText()),
                ],
              );
            });
          },
        ),
      ),
    );
  }

  Widget _tickerText() => Row(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.campaign_rounded, size: 13, color: AppColors.gold),
        const SizedBox(width: 8),
        Text(widget.text, style: const TextStyle(fontSize: 12, color: Colors.white), maxLines: 1),
      ]);
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: CircularProgressIndicator(color: AppColors.navy));
}
