import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'core/theme/app_theme.dart';
import 'core/auth_gate.dart';
import 'data/api_client.dart';
import 'data/repositories/auth_repository.dart';
import 'data/repositories/search_repository.dart';
import 'data/repositories/booking_repository.dart';
import 'data/repositories/misc_repositories.dart';
import 'state/providers.dart';
import 'screens/profile/notifications_screen.dart';
import 'l10n/app_localizations.dart';

/// Flip this to false (or drive it from --dart-define) once your Express
/// backend is deployed and ApiConfig.baseUrl points at it. Every screen in
/// this app is already wired against the abstract repository interfaces, so
/// this is the entire cutover — no screen code changes needed.
class AppConfig {
  static const bool useMockData = bool.fromEnvironment('USE_MOCK_DATA', defaultValue: true);
}

void main() {
  runApp(const CarliftApp());
}

class CarliftApp extends StatelessWidget {
  const CarliftApp({super.key});

  @override
  Widget build(BuildContext context) {
    final apiClient = ApiClient();

    return MultiProvider(
      providers: [
        Provider<ApiClient>.value(value: apiClient),
        ChangeNotifierProvider(
          create: (_) => AuthProvider(AppConfig.useMockData ? MockAuthRepository() : HttpAuthRepository(apiClient)),
        ),
        ChangeNotifierProvider(
          create: (_) => SearchProvider(AppConfig.useMockData ? MockSearchRepository() : HttpSearchRepository(apiClient)),
        ),
        ChangeNotifierProvider(
          create: (_) => BookingProvider(AppConfig.useMockData ? MockBookingRepository() : HttpBookingRepository(apiClient)),
        ),
        ChangeNotifierProvider(
          create: (_) => FavoritesProvider(AppConfig.useMockData ? MockFavoritesRepository() : HttpFavoritesRepository(apiClient)),
        ),
        ChangeNotifierProvider(
          create: (_) => NotificationsProvider(AppConfig.useMockData ? MockNotificationsRepository() : HttpNotificationsRepository(apiClient)),
        ),
        ChangeNotifierProvider(
          create: (_) => AdsProvider(AppConfig.useMockData ? MockAdsRepository() : HttpAdsRepository(apiClient)),
        ),
      ],
      child: Consumer<AuthProvider>(
        builder: (context, auth, _) {
          return MaterialApp(
            title: 'Dubai Carlift',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.light(),
            locale: auth.locale,
            supportedLocales: const [
              Locale('en'), Locale('ar'), Locale('ur'), Locale('ne'), Locale('tl'), Locale('bn'),
            ],
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            localeResolutionCallback: (locale, supported) {
              // Falls back to English if the device/user locale isn't one of our 6 packs.
              for (final s in supported) {
                if (s.languageCode == locale?.languageCode) return s;
              }
              return const Locale('en');
            },
            builder: (context, child) {
              // RTL languages (Arabic, Urdu) automatically mirror the whole tree —
              // Flutter's Directionality handles this for every widget above,
              // no per-screen flip logic needed (unlike a hand-rolled web layout).
              return child!;
            },
            routes: {
              '/notifications': (context) => const NotificationsScreen(),
            },
            home: const AuthGate(),
          );
        },
      ),
    );
  }
}
