import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'network/api_client.dart';
import 'payments/payment_service.dart';
import 'realtime/realtime_service.dart';

/// Flip via --dart-define=USE_MOCK_DATA=false once your backend is deployed.
/// Every repository provider below reads this once, at composition time —
/// no screen or controller checks it directly.
final useMockDataProvider = Provider<bool>((ref) {
  return const bool.fromEnvironment('USE_MOCK_DATA', defaultValue: true);
});

final apiClientProvider = Provider<ApiClient>((ref) => ApiClient());

final realtimeServiceProvider = Provider<RealtimeService>((ref) {
  final useMock = ref.watch(useMockDataProvider);
  if (useMock) return MockRealtimeService();

  const wsUrl = String.fromEnvironment('REALTIME_WS_URL', defaultValue: 'wss://api.your-carlift-domain.com/realtime');
  final service = WebSocketRealtimeService(wsUrl: wsUrl);
  ref.onDispose(service.disconnect);
  return service;
});

final paymentServiceProvider = Provider<PaymentService>((ref) {
  final useMock = ref.watch(useMockDataProvider);
  if (useMock) return MockPaymentService();

  final api = ref.watch(apiClientProvider);
  return CompositePaymentService({
    PaymentMethod.card: CardPaymentService(api),
    PaymentMethod.tabby: TabbyPaymentService(api),
    PaymentMethod.cash: CashPaymentService(api),
  });
});
