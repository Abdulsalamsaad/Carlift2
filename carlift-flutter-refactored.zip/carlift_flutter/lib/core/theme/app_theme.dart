import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF0B1F2A);
  static const navySoft = Color(0xFF132C3A);
  static const sand = Color(0xFFF2F6F5);
  static const card = Color(0xFFFFFFFF);
  static const gold = Color(0xFFE8A33D);
  static const goldDeep = Color(0xFFC6821F);
  static const teal = Color(0xFF16645C);
  static const brick = Color(0xFFC4432B);
  static const text = Color(0xFF14202B);
  static const muted = Color(0xFF5C6B70);
  static const line = Color(0xFFE1E7E6);
  static const tealTint = Color(0xFFEAF3F2);
  static const goldTint = Color(0xFFFBF3E4);
  static const brickTint = Color(0xFFFBEAE6);
}

class AppTheme {
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.sand,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.navy,
        primary: AppColors.navy,
        secondary: AppColors.gold,
        surface: AppColors.card,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navy,
          padding: const EdgeInsets.symmetric(vertical: 16),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 2,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.sand,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
    );
  }
}

/// Responsive helper — the layout adapts between a phone-width column (default),
/// a centered tablet column, and a max-width column for web/desktop, rather than
/// hardcoding a fixed phone frame.
class Responsive {
  static double contentMaxWidth(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    if (w >= 900) return 480; // desktop web: keep the mobile-style column centered
    if (w >= 600) return 560; // tablet
    return w; // phone: full width
  }

  static bool isCompact(BuildContext context) => MediaQuery.of(context).size.width < 600;
}

String zoneCode(String zone) {
  final clean = zone.replaceAll(RegExp(r'[^A-Za-z ]'), '');
  final words = clean.split(' ').where((w) => w.isNotEmpty).toList();
  if (words.length > 1) {
    return (words[0][0] + words[1][0] + (words[1].length > 1 ? words[1][1] : words[0][1])).toUpperCase();
  }
  return clean.length >= 3 ? clean.substring(0, 3).toUpperCase() : clean.toUpperCase();
}
