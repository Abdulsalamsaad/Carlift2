import 'package:dio/dio.dart';
import '../storage/token_storage.dart';
import 'api_exception.dart';

class ApiConfig {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.your-carlift-domain.com/api',
  );
  static const Duration connectTimeout = Duration(seconds: 12);
  static const Duration receiveTimeout = Duration(seconds: 15);
}

/// Central network client. Every repository (auth, search, booking, favorites,
/// notifications, ads) is written against this — it's the single seam between
/// the app and the live backend. Nothing above this layer knows Dio exists.
///
/// Responsibilities:
///  - attach the JWT access token to every request
///  - transparently refresh + retry once on a 401
///  - map every failure (network, timeout, 4xx/5xx) into a single ApiException
///    type so repositories/UI never touch Dio's exception types directly
///  - centralized request/response logging (debug builds only)
class ApiClient {
  final Dio dio;
  final TokenStorage _tokenStorage;

  ApiClient({TokenStorage? tokenStorage})
      : _tokenStorage = tokenStorage ?? TokenStorage(),
        dio = Dio(BaseOptions(
          baseUrl: ApiConfig.baseUrl,
          connectTimeout: ApiConfig.connectTimeout,
          receiveTimeout: ApiConfig.receiveTimeout,
          headers: {'Content-Type': 'application/json'},
        )) {
    dio.interceptors.addAll([
      _authInterceptor(),
      _refreshInterceptor(),
      if (_kDebug) LogInterceptor(requestBody: true, responseBody: true, error: true),
    ]);
  }

  InterceptorsWrapper _authInterceptor() {
    return InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _tokenStorage.readAccessToken();
        if (token != null) options.headers['Authorization'] = 'Bearer $token';
        handler.next(options);
      },
    );
  }

  InterceptorsWrapper _refreshInterceptor() {
    return InterceptorsWrapper(
      onError: (error, handler) async {
        if (error.response?.statusCode != 401) return handler.next(error);

        final refreshToken = await _tokenStorage.readRefreshToken();
        if (refreshToken == null) return handler.next(error);

        try {
          final res = await dio.post('/auth/refresh', data: {'refreshToken': refreshToken});
          final newAccess = res.data['data']['accessToken'] as String;
          await _tokenStorage.saveAccessToken(newAccess);

          final retryReq = error.requestOptions;
          retryReq.headers['Authorization'] = 'Bearer $newAccess';
          final retried = await dio.fetch(retryReq);
          return handler.resolve(retried);
        } catch (_) {
          await _tokenStorage.clear();
          return handler.next(error);
        }
      },
    );
  }

  /// Wraps a Dio call and normalizes every failure into an ApiException.
  /// Repositories call this instead of touching `dio` directly:
  ///   final res = await apiClient.request(() => apiClient.dio.get('/routes/search', ...));
  Future<T> request<T>(Future<T> Function() call) async {
    try {
      return await call();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }

  static const _kDebug = bool.fromEnvironment('dart.vm.product') == false;
}
