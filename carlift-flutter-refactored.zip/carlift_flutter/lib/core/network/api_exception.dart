import 'package:dio/dio.dart';

enum ApiErrorType { network, timeout, unauthorized, forbidden, notFound, validation, server, unknown }

/// The only exception type repositories and UI ever need to catch.
/// Screens can switch on `.type` for behavior (e.g. redirect to login on
/// `unauthorized`) and show `.message` directly — it's already the
/// server's localized message when available (see errorHandler.js on the
/// backend, which now returns req.t()-translated strings).
class ApiException implements Exception {
  final ApiErrorType type;
  final String message;
  final int? statusCode;
  final dynamic details;

  ApiException(this.message, {this.type = ApiErrorType.unknown, this.statusCode, this.details});

  factory ApiException.fromDio(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException('Request timed out. Check your connection.', type: ApiErrorType.timeout);
      case DioExceptionType.connectionError:
        return ApiException('No network connection.', type: ApiErrorType.network);
      case DioExceptionType.badResponse:
        return _fromResponse(e);
      default:
        return ApiException(e.message ?? 'Something went wrong.', type: ApiErrorType.unknown);
    }
  }

  static ApiException _fromResponse(DioException e) {
    final status = e.response?.statusCode ?? 0;
    final body = e.response?.data;
    final serverMessage = (body is Map && body['message'] is String) ? body['message'] as String : null;
    final details = body is Map ? body['details'] ?? body['errors'] : null;

    ApiErrorType type;
    switch (status) {
      case 401:
        type = ApiErrorType.unauthorized;
        break;
      case 403:
        type = ApiErrorType.forbidden;
        break;
      case 404:
        type = ApiErrorType.notFound;
        break;
      case 422:
        type = ApiErrorType.validation;
        break;
      default:
        type = status >= 500 ? ApiErrorType.server : ApiErrorType.unknown;
    }

    return ApiException(serverMessage ?? 'Request failed ($status)', type: type, statusCode: status, details: details);
  }

  @override
  String toString() => message;
}
