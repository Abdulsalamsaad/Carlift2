import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../storage/token_storage.dart';

/// One live position update for a trip, e.g. a driver's app publishing its
/// GPS coordinates every few seconds while a trip is in progress.
class LocationUpdate {
  final String tripId;
  final double lat;
  final double lng;
  final double? heading;
  final double? speedKmh;
  final DateTime timestamp;

  LocationUpdate({
    required this.tripId, required this.lat, required this.lng,
    this.heading, this.speedKmh, required this.timestamp,
  });

  factory LocationUpdate.fromJson(Map<String, dynamic> j) => LocationUpdate(
        tripId: j['tripId'] as String,
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        heading: (j['heading'] as num?)?.toDouble(),
        speedKmh: (j['speedKmh'] as num?)?.toDouble(),
        timestamp: DateTime.parse(j['timestamp'] as String),
      );
}

enum RealtimeStatus { disconnected, connecting, connected, error }

/// Abstract so the transport (WebSocket vs Firebase Realtime Database vs
/// Firestore snapshots) is swappable without touching any screen. A driver
/// app would implement the *publish* side of this same contract.
abstract class RealtimeService {
  Stream<RealtimeStatus> get status;

  /// Subscribes to live location updates for a single trip (e.g. today's
  /// instance of a passenger's booked route). Call [unsubscribeFromTrip]
  /// or let the returned StreamSubscription be cancelled when the tracking
  /// screen is disposed.
  Stream<LocationUpdate> subscribeToTrip(String tripId);
  void unsubscribeFromTrip(String tripId);

  Future<void> connect();
  Future<void> disconnect();
}

/// WebSocket implementation. Expects a backend gateway that:
///   - accepts a connection at `wss://.../realtime?token=<jwt>`
///   - on receiving {"action":"subscribe","tripId":"..."}, starts forwarding
///     that trip's location updates as {"tripId":...,"lat":...,"lng":...,"timestamp":...}
///   - accepts {"action":"unsubscribe","tripId":"..."} to stop
/// This is a skeleton: the wire protocol above is a proposal, not a contract
/// your backend already implements — align it with whatever your driver
/// app's publish side actually sends (see the note below on the driver-side
/// symmetry).
class WebSocketRealtimeService implements RealtimeService {
  final String wsUrl;
  final TokenStorage _tokenStorage;

  WebSocketChannel? _channel;
  StreamSubscription? _channelSub;
  final _statusController = StreamController<RealtimeStatus>.broadcast();
  final _tripControllers = <String, StreamController<LocationUpdate>>{};

  WebSocketRealtimeService({required this.wsUrl, TokenStorage? tokenStorage})
      : _tokenStorage = tokenStorage ?? TokenStorage();

  @override
  Stream<RealtimeStatus> get status => _statusController.stream;

  @override
  Future<void> connect() async {
    _statusController.add(RealtimeStatus.connecting);
    try {
      final token = await _tokenStorage.readAccessToken();
      _channel = WebSocketChannel.connect(Uri.parse('$wsUrl?token=$token'));
      _channelSub = _channel!.stream.listen(
        _handleMessage,
        onError: (_) => _statusController.add(RealtimeStatus.error),
        onDone: () => _statusController.add(RealtimeStatus.disconnected),
      );
      _statusController.add(RealtimeStatus.connected);
    } catch (_) {
      _statusController.add(RealtimeStatus.error);
    }
  }

  void _handleMessage(dynamic raw) {
    try {
      final json = jsonDecode(raw as String) as Map<String, dynamic>;
      final update = LocationUpdate.fromJson(json);
      _tripControllers[update.tripId]?.add(update);
    } catch (_) {
      // malformed frame — ignore rather than crash the socket listener
    }
  }

  @override
  Stream<LocationUpdate> subscribeToTrip(String tripId) {
    final controller = _tripControllers.putIfAbsent(tripId, () => StreamController<LocationUpdate>.broadcast());
    _channel?.sink.add(jsonEncode({'action': 'subscribe', 'tripId': tripId}));
    return controller.stream;
  }

  @override
  void unsubscribeFromTrip(String tripId) {
    _channel?.sink.add(jsonEncode({'action': 'unsubscribe', 'tripId': tripId}));
    _tripControllers.remove(tripId)?.close();
  }

  @override
  Future<void> disconnect() async {
    await _channelSub?.cancel();
    await _channel?.sink.close();
    for (final c in _tripControllers.values) {
      await c.close();
    }
    _tripControllers.clear();
    _statusController.add(RealtimeStatus.disconnected);
  }
}

/// Local/offline stand-in — emits a simulated moving point so the tracking
/// UI has something to render without a live backend. This is what
/// AppConfig.useMockData=true wires up (see core/di.dart).
class MockRealtimeService implements RealtimeService {
  final _statusController = StreamController<RealtimeStatus>.broadcast();
  final _timers = <String, Timer>{};
  final _tripControllers = <String, StreamController<LocationUpdate>>{};

  @override
  Stream<RealtimeStatus> get status => _statusController.stream;

  @override
  Future<void> connect() async => _statusController.add(RealtimeStatus.connected);

  @override
  Stream<LocationUpdate> subscribeToTrip(String tripId) {
    final controller = _tripControllers.putIfAbsent(tripId, () => StreamController<LocationUpdate>.broadcast());
    double t = 0;
    _timers[tripId]?.cancel();
    _timers[tripId] = Timer.periodic(const Duration(seconds: 2), (_) {
      t += 0.05;
      // Interpolates along a fixed two-point line — purely illustrative.
      controller.add(LocationUpdate(
        tripId: tripId, lat: 25.20 + t * 0.01, lng: 55.27 - t * 0.02,
        heading: 45, speedKmh: 38, timestamp: DateTime.now(),
      ));
    });
    return controller.stream;
  }

  @override
  void unsubscribeFromTrip(String tripId) {
    _timers.remove(tripId)?.cancel();
    _tripControllers.remove(tripId)?.close();
  }

  @override
  Future<void> disconnect() async {
    for (final t in _timers.values) {
      t.cancel();
    }
    for (final c in _tripControllers.values) {
      await c.close();
    }
    _timers.clear();
    _tripControllers.clear();
    _statusController.add(RealtimeStatus.disconnected);
  }
}

// ---------------------------------------------------------------------------
// Firebase alternative (not wired by default — this app has no Firebase
// project configured, and adding firebase_core/cloud_firestore to pubspec.yaml
// without a real google-services.json would break `flutter pub get`). If you
// choose Firestore instead of a WebSocket gateway:
//
//   class FirestoreRealtimeService implements RealtimeService {
//     final _db = FirebaseFirestore.instance;
//     @override
//     Stream<LocationUpdate> subscribeToTrip(String tripId) {
//       return _db.collection('trip_locations').doc(tripId).snapshots()
//         .map((doc) => LocationUpdate.fromJson(doc.data()!));
//     }
//     // A driver app would `.set()` onto that same document on a location
//     // timer — the passenger app here is purely a listener.
//   }
//
// Swapping this in is a one-line change in core/di.dart; nothing in the
// booking feature or the tracking screen needs to know which transport is
// active, since both implement the same RealtimeService contract.
// ---------------------------------------------------------------------------
