import 'package:shared_preferences/shared_preferences.dart';

/// Isolated so it's the one file you touch to move tokens into
/// `flutter_secure_storage` for production (SharedPreferences is not
/// encrypted at rest — fine for the access token's short lifetime, not
/// recommended for the longer-lived refresh token in a shipped app).
class TokenStorage {
  static const _accessKey = 'carlift_access_token';
  static const _refreshKey = 'carlift_refresh_token';

  Future<void> saveTokens({required String accessToken, required String refreshToken}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessKey, accessToken);
    await prefs.setString(_refreshKey, refreshToken);
  }

  Future<void> saveAccessToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessKey, token);
  }

  Future<String?> readAccessToken() async => (await SharedPreferences.getInstance()).getString(_accessKey);
  Future<String?> readRefreshToken() async => (await SharedPreferences.getInstance()).getString(_refreshKey);

  Future<bool> hasSession() async => await readAccessToken() != null;

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessKey);
    await prefs.remove(_refreshKey);
  }
}
