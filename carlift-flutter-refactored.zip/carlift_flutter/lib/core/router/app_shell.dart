import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../../state/providers.dart';
import '../../screens/search/flight_search_screen.dart';
import '../../screens/rides/my_rides_screen.dart';
import '../../screens/profile/profile_home_screen.dart';
import '../../l10n/app_localizations.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final t = AppLocalizations.of(context)!;
      await context.read<BookingProvider>().load();
      await context.read<FavoritesProvider>().load();
      await context.read<NotificationsProvider>().seedIfEmpty(
            t.welcomeNotifTitle, t.welcomeNotifBody, t.promoNotifTitle, t.promoNotifBody,
          );
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final booking = context.watch<BookingProvider>();

    final tabs = [
      const FlightSearchScreen(),
      Scaffold(appBar: AppBar(title: Text(t.myRidesTitle)), body: const MyRidesScreen()),
      Scaffold(appBar: AppBar(title: Text(t.profileTitle)), body: const ProfileHomeScreen()),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: tabs),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Colors.white,
        indicatorColor: AppColors.goldTint,
        destinations: [
          NavigationDestination(icon: const Icon(Icons.search_rounded), label: t.navSearch),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: booking.activeCount > 0,
              label: Text('${booking.activeCount}'),
              child: const Icon(Icons.confirmation_num_outlined),
            ),
            label: t.navRides,
          ),
          NavigationDestination(icon: const Icon(Icons.person_outline_rounded), label: t.navProfile),
        ],
      ),
    );
  }
}
