import '../network/api_client.dart';

enum PaymentMethod { tabby, card, cash }
enum PaymentStatus { pending, requiresAction, succeeded, failed }

class PaymentRequest {
  final String subscriptionId; // or a pending-booking reference before the subscription exists
  final double amount;
  final String currency; // "AED"
  final PaymentMethod method;
  final Map<String, dynamic>? methodDetails; // e.g. tokenized card fields — never raw PAN

  PaymentRequest({
    required this.subscriptionId, required this.amount, required this.method,
    this.currency = 'AED', this.methodDetails,
  });
}

class PaymentResult {
  final PaymentStatus status;
  final String? providerReference; // gateway's transaction/charge ID
  final String? redirectUrl; // for methods needing a hosted checkout step (e.g. Tabby)
  final String? errorMessage;

  PaymentResult({required this.status, this.providerReference, this.redirectUrl, this.errorMessage});
}

/// One interface, one call site (CheckoutScreen), swappable gateway per
/// PaymentMethod. Nothing outside this file should ever hold a card number,
/// a Tabby SDK reference, or a gateway secret — those live behind whichever
/// concrete implementation is selected.
abstract class PaymentService {
  Future<PaymentResult> pay(PaymentRequest request);

  /// Called after a redirect-based flow (Tabby) returns control to the app,
  /// to confirm the final status server-side rather than trusting the
  /// redirect URL's query params.
  Future<PaymentResult> confirm(String providerReference);
}

/// Dispatches to the correct concrete gateway based on PaymentRequest.method.
/// This is what the app actually injects — screens depend on PaymentService,
/// never on a specific gateway class.
class CompositePaymentService implements PaymentService {
  final Map<PaymentMethod, PaymentService> _byMethod;
  CompositePaymentService(this._byMethod);

  @override
  Future<PaymentResult> pay(PaymentRequest request) => _byMethod[request.method]!.pay(request);

  @override
  Future<PaymentResult> confirm(String providerReference) {
    // In practice you'd tag the reference with its method, or track the
    // in-flight method in state; simplified here since only Tabby uses confirm().
    return _byMethod[PaymentMethod.tabby]!.confirm(providerReference);
  }
}

/// Card payments — your backend should create a PaymentIntent-style charge
/// server-side (Stripe, Network International, etc.) and this just posts the
/// tokenized method + amount to it. The Luhn/expiry validation that already
/// lives in the checkout UI is a UX nicety, not a security boundary — real
/// validation and PCI scope stay entirely server-/gateway-side.
class CardPaymentService implements PaymentService {
  final ApiClient _api;
  CardPaymentService(this._api);

  @override
  Future<PaymentResult> pay(PaymentRequest request) {
    return _api.request(() async {
      final res = await _api.dio.post('/payments/card', data: {
        'subscriptionId': request.subscriptionId,
        'amount': request.amount,
        'currency': request.currency,
        ...?request.methodDetails, // e.g. { "paymentMethodToken": "tok_..." } from a card SDK, never raw PAN
      });
      final data = res.data['data'];
      return PaymentResult(
        status: data['status'] == 'succeeded' ? PaymentStatus.succeeded : PaymentStatus.failed,
        providerReference: data['chargeId'],
      );
    });
  }

  @override
  Future<PaymentResult> confirm(String providerReference) =>
      throw UnimplementedError('Card payments confirm synchronously in pay(); no separate confirm step.');
}

/// Tabby (buy-now-pay-later) — typically a redirect/hosted-page flow: create
/// a checkout session server-side, send the shopper to `redirectUrl`, then
/// confirm the outcome when they return to the app via deep link.
class TabbyPaymentService implements PaymentService {
  final ApiClient _api;
  TabbyPaymentService(this._api);

  @override
  Future<PaymentResult> pay(PaymentRequest request) {
    return _api.request(() async {
      final res = await _api.dio.post('/payments/tabby/sessions', data: {
        'subscriptionId': request.subscriptionId, 'amount': request.amount, 'currency': request.currency,
      });
      final data = res.data['data'];
      return PaymentResult(status: PaymentStatus.requiresAction, providerReference: data['sessionId'], redirectUrl: data['redirectUrl']);
    });
  }

  @override
  Future<PaymentResult> confirm(String providerReference) {
    return _api.request(() async {
      final res = await _api.dio.get('/payments/tabby/sessions/$providerReference');
      final status = res.data['data']['status'] as String;
      return PaymentResult(
        status: status == 'authorized' ? PaymentStatus.succeeded : PaymentStatus.failed,
        providerReference: providerReference,
      );
    });
  }
}

/// Cash — nothing to charge; this just records the reservation server-side
/// so the driver's app can show "cash due" on pickup.
class CashPaymentService implements PaymentService {
  final ApiClient _api;
  CashPaymentService(this._api);

  @override
  Future<PaymentResult> pay(PaymentRequest request) {
    return _api.request(() async {
      await _api.dio.post('/payments/cash-reservations', data: {'subscriptionId': request.subscriptionId, 'amount': request.amount});
      return PaymentResult(status: PaymentStatus.pending); // "pending" = due at pickup, not a failure state
    });
  }

  @override
  Future<PaymentResult> confirm(String providerReference) async => PaymentResult(status: PaymentStatus.pending);
}

/// Offline stand-in for all three methods — reproduces the original
/// checkout's simulated 900ms processing delay and always-succeeds outcome,
/// so switching AppConfig.useMockData doesn't change the UX timing.
class MockPaymentService implements PaymentService {
  @override
  Future<PaymentResult> pay(PaymentRequest request) async {
    await Future.delayed(const Duration(milliseconds: 900));
    return PaymentResult(status: PaymentStatus.succeeded, providerReference: 'mock_${DateTime.now().millisecondsSinceEpoch}');
  }

  @override
  Future<PaymentResult> confirm(String providerReference) async => PaymentResult(status: PaymentStatus.succeeded, providerReference: providerReference);
}
