import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/network/api_client.dart';
import '../../../shared/models.dart';
import '../domain/booking_repository.dart';

/// Fully functional offline implementation — used when AppConfig.useMockData
/// is true (see core/di.dart). Lets the whole app run, demo, and be tested
/// with zero backend deployed, while implementing the exact same contract
/// the live version does.
class MockBookingRepository implements BookingRepository {
  static const _key = 'carlift_mock_subscriptions';

  Future<List<Subscription>> _readAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((j) => Subscription.fromJson(j)).toList();
  }

  Future<void> _writeAll(List<Subscription> subs) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(subs.map((s) => s.toJson()).toList()));
  }

  @override
  Future<List<Subscription>> listMySubscriptions() => _readAll();

  @override
  Future<Subscription> createSubscription({
    required RideOption ride, required ScheduleConfig config, required String paymentMethod, String? paymentReference,
  }) async {
    await Future.delayed(const Duration(milliseconds: 400));
    final sub = Subscription(
      id: 'sub_${DateTime.now().millisecondsSinceEpoch}',
      origin: ride.originZone, destination: ride.destinationZone, company: ride.company, initials: ride.initials,
      colorHex: ride.colorHex,
      departureLabel: '${ride.departureTime.hour.toString().padLeft(2, '0')}:${ride.departureTime.minute.toString().padLeft(2, '0')}',
      days: config.days, plan: config.plan, price: ride.priceForPlan(config.plan), paymentMethod: paymentMethod,
      status: 'active', createdAt: DateTime.now(), driverName: ride.driverName, driverPhone: ride.driverPhone,
      busNumber: ride.busNumber, messages: const [],
    );
    final all = await _readAll();
    await _writeAll([sub, ...all]);
    return sub;
  }

  @override
  Future<void> cancelSubscription(String id) async {
    final all = await _readAll();
    final idx = all.indexWhere((s) => s.id == id);
    if (idx == -1) throw ApiException('Subscription not found', type: ApiErrorType.notFound);
    all[idx].status = 'cancelled';
    await _writeAll(all);
  }

  @override
  Future<void> sendDriverMessage(String subscriptionId, String text) async {
    final all = await _readAll();
    final idx = all.indexWhere((s) => s.id == subscriptionId);
    if (idx == -1) throw ApiException('Subscription not found', type: ApiErrorType.notFound);
    all[idx].messages = [...all[idx].messages, ChatMessage(from: 'me', text: text, at: DateTime.now())];
    await _writeAll(all);
  }

  @override
  Future<String?> resolveTodaysTripId(String subscriptionId) async {
    // Mock mode has no real Trip table — return a stable fake id so the
    // tracking screen still has something to subscribe MockRealtimeService to.
    return 'mock_trip_$subscriptionId';
  }
}

/// Live backend implementation — POST/GET/PATCH /api/subscriptions,
/// GET /api/subscriptions/:id/messages (see subscription.controller.js),
/// plus a trips lookup for the tracking screen.
class HttpBookingRepository implements BookingRepository {
  final ApiClient _api;
  HttpBookingRepository(this._api);

  @override
  Future<List<Subscription>> listMySubscriptions() {
    return _api.request(() async {
      final res = await _api.dio.get('/subscriptions');
      return (res.data['data'] as List).map((j) => Subscription.fromJson(j)).toList();
    });
  }

  @override
  Future<Subscription> createSubscription({
    required RideOption ride, required ScheduleConfig config, required String paymentMethod, String? paymentReference,
  }) {
    return _api.request(() async {
      final res = await _api.dio.post('/subscriptions', data: {
        'routeId': ride.routeId, 'scheduleId': ride.scheduleId, 'planType': config.plan,
        'selectedWorkdays': config.days, 'paymentMethod': paymentMethod,
        if (paymentReference != null) 'paymentReference': paymentReference,
      });
      return Subscription.fromJson(res.data['data']);
    });
  }

  @override
  Future<void> cancelSubscription(String id) {
    return _api.request(() => _api.dio.patch('/subscriptions/$id', data: {'status': 'cancelled'}));
  }

  @override
  Future<void> sendDriverMessage(String subscriptionId, String text) {
    return _api.request(() => _api.dio.post('/subscriptions/$subscriptionId/messages', data: {'text': text}));
  }

  @override
  Future<String?> resolveTodaysTripId(String subscriptionId) {
    return _api.request(() async {
      final res = await _api.dio.get('/subscriptions/$subscriptionId/today-trip');
      return res.data['data']?['tripId'] as String?;
    });
  }
}
