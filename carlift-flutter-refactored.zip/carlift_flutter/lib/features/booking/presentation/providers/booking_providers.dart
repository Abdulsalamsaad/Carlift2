import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/di.dart';
import '../../../shared/models.dart';
import '../data/booking_repository_impl.dart';
import '../domain/booking_repository.dart';

final bookingRepositoryProvider = Provider<BookingRepository>((ref) {
  final useMock = ref.watch(useMockDataProvider);
  if (useMock) return MockBookingRepository();
  return HttpBookingRepository(ref.watch(apiClientProvider));
});

/// Loads + exposes the signed-in passenger's subscriptions. AsyncNotifier
/// gives screens loading/error/data states for free via AsyncValue, instead
/// of the manual `loading` booleans the Provider-based version needed.
class BookingController extends AsyncNotifier<List<Subscription>> {
  @override
  Future<List<Subscription>> build() {
    return ref.read(bookingRepositoryProvider).listMySubscriptions();
  }

  int get activeCount => state.valueOrNull?.where((s) => s.status == 'active').length ?? 0;

  Future<Subscription> book({required RideOption ride, required ScheduleConfig config, required String paymentMethod, String? paymentReference}) async {
    final repo = ref.read(bookingRepositoryProvider);
    final sub = await repo.createSubscription(ride: ride, config: config, paymentMethod: paymentMethod, paymentReference: paymentReference);
    state = AsyncData([sub, ...(state.valueOrNull ?? [])]);
    return sub;
  }

  Future<void> cancel(String id) async {
    await ref.read(bookingRepositoryProvider).cancelSubscription(id);
    ref.invalidateSelf();
    await future;
  }

  Future<void> sendMessage(String subId, String text) async {
    await ref.read(bookingRepositoryProvider).sendDriverMessage(subId, text);
    ref.invalidateSelf();
    await future;
  }
}

final bookingControllerProvider = AsyncNotifierProvider<BookingController, List<Subscription>>(BookingController.new);
