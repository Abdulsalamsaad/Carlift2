import '../../../shared/models.dart';

/// The contract the presentation layer (providers/screens) depends on.
/// It knows nothing about Dio, SharedPreferences, or HTTP status codes —
/// that's entirely inside the `data/` implementations. This is what makes
/// the payment-gateway and driver-app integrations additive rather than
/// invasive: BookingRepositoryImpl changes, this file and every screen
/// that depends on it do not.
abstract class BookingRepository {
  Future<List<Subscription>> listMySubscriptions();

  Future<Subscription> createSubscription({
    required RideOption ride,
    required ScheduleConfig config,
    required String paymentMethod,
    String? paymentReference, // set once PaymentService.pay() has succeeded/is pending
  });

  Future<void> cancelSubscription(String id);
  Future<void> sendDriverMessage(String subscriptionId, String text);

  /// Resolves today's live Trip id for a subscription, so the tracking
  /// screen has something to hand to RealtimeService.subscribeToTrip().
  /// Null until a bus is actually assigned for today (see the backend note
  /// in route.controller.js about Trip being the source of truth here).
  Future<String?> resolveTodaysTripId(String subscriptionId);
}
