import 'package:flutter/material.dart';
import '../data/models/models.dart';
import '../data/repositories/auth_repository.dart';
import '../data/repositories/search_repository.dart';
import '../data/repositories/booking_repository.dart';
import '../data/repositories/misc_repositories.dart';

/// Auth + current-user state. Also owns the active locale, since preferred
/// language lives on the User record (mirrors preferred_language in Postgres).
class AuthProvider extends ChangeNotifier {
  final AuthRepository repo;
  AuthProvider(this.repo);

  AppUser? user;
  bool loading = true;
  String? error;

  Locale get locale => Locale(user?.preferredLanguage ?? 'en');

  Future<void> restore() async {
    loading = true;
    notifyListeners();
    user = await repo.restoreSession();
    loading = false;
    notifyListeners();
  }

  Future<bool> register({required String name, required String phone, required String email, required String password}) async {
    error = null;
    try {
      user = await repo.register(name: name, phone: phone, email: email, password: password);
      notifyListeners();
      return true;
    } catch (e) {
      error = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<bool> login({required String email, required String password}) async {
    error = null;
    try {
      user = await repo.login(email: email, password: password);
      notifyListeners();
      return true;
    } catch (e) {
      error = e.toString();
      notifyListeners();
      return false;
    }
  }

  Future<void> updateProfile(AppUser updated) async {
    user = await repo.updateProfile(updated);
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    if (user == null) return;
    user = await repo.updateProfile(user!.copyWith(preferredLanguage: code));
    notifyListeners();
  }

  Future<void> logout() async {
    await repo.logout();
    user = null;
    notifyListeners();
  }
}

class SearchProvider extends ChangeNotifier {
  final SearchRepository repo;
  SearchProvider(this.repo);

  List<String> pickupZones = [];
  List<String> destinationZones = [];
  List<RideOption> results = [];
  bool loading = false;
  bool searched = false;
  SearchQuery query = SearchQuery(origin: 'Satwa', destination: 'Dubai Marina', frequency: 'monthly');

  Future<void> loadZones() async {
    pickupZones = await repo.pickupZones();
    destinationZones = await repo.destinationZones();
    notifyListeners();
  }

  void updateQuery(SearchQuery q) {
    query = q;
    notifyListeners();
  }

  Future<void> search() async {
    loading = true;
    searched = true;
    notifyListeners();
    results = await repo.search(query);
    loading = false;
    notifyListeners();
  }

  void sortByTime() {
    results = [...results]..sort((a, b) => a.departureTime.compareTo(b.departureTime));
    notifyListeners();
  }

  void sortByPrice() {
    results = [...results]..sort((a, b) => a.priceDaily.compareTo(b.priceDaily));
    notifyListeners();
  }
}

class BookingProvider extends ChangeNotifier {
  final BookingRepository repo;
  BookingProvider(this.repo);

  List<Subscription> subscriptions = [];
  bool loading = false;

  int get activeCount => subscriptions.where((s) => s.status == 'active').length;

  Future<void> load() async {
    loading = true;
    notifyListeners();
    subscriptions = await repo.listMySubscriptions();
    loading = false;
    notifyListeners();
  }

  Future<Subscription> book({required RideOption ride, required ScheduleConfig config, required String paymentMethod}) async {
    final sub = await repo.createSubscription(ride: ride, config: config, paymentMethod: paymentMethod);
    subscriptions = [sub, ...subscriptions];
    notifyListeners();
    return sub;
  }

  Future<void> cancel(String id) async {
    await repo.cancelSubscription(id);
    await load();
  }

  Future<void> sendMessage(String subId, String text) async {
    await repo.sendDriverMessage(subId, text);
    await load();
  }
}

class FavoritesProvider extends ChangeNotifier {
  final FavoritesRepository repo;
  FavoritesProvider(this.repo);

  List<FavoriteRoute> favorites = [];

  Future<void> load() async {
    favorites = await repo.list();
    notifyListeners();
  }

  bool isFavorite(RideOption ride) => favorites.any((f) => f.routeId == ride.routeId && f.scheduleId == ride.scheduleId);

  Future<void> toggle(RideOption ride) async {
    await repo.toggle(ride);
    await load();
  }

  Future<void> remove(String id) async {
    await repo.remove(id);
    await load();
  }
}

class NotificationsProvider extends ChangeNotifier {
  final NotificationsRepository repo;
  NotificationsProvider(this.repo);

  List<AppNotification> notifications = [];

  int get unreadCount => notifications.where((n) => !n.isRead).length;

  Future<void> load() async {
    notifications = await repo.list();
    notifyListeners();
  }

  Future<void> seedIfEmpty(String tw, String bw, String tp, String bp) async {
    await repo.seedWelcome(tw, bw, tp, bp);
    await load();
  }

  Future<void> markRead(String id) async {
    await repo.markRead(id);
    await load();
  }

  Future<void> markAllRead() async {
    await repo.markAllRead();
    await load();
  }
}

class AdsProvider extends ChangeNotifier {
  final AdsRepository repo;
  AdsProvider(this.repo);

  final Map<String, AdBanner?> _cache = {};

  Future<AdBanner?> forZone(String zone) async {
    if (_cache.containsKey(zone)) return _cache[zone];
    final ad = await repo.activeAdFor(zone);
    _cache[zone] = ad;
    return ad;
  }

  Future<void> trackClick(String adId) => repo.trackClick(adId);
}
