import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Points at the Express/Prisma backend from the carlift-transit-platform
/// project. Change this per environment (--dart-define=API_BASE_URL=...).
class ApiConfig {
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.your-carlift-domain.com/api',
  );
}

/// Thin wrapper around Dio that attaches the JWT access token to every
/// request and exposes a couple of storage helpers for the token pair.
/// This is the single seam between the app and the live backend — every
/// repository below is written against this client, so switching
/// AppConfig.useMockData to false in main.dart is the entire integration step.
class ApiClient {
  final Dio _dio;
  static const _accessTokenKey = 'carlift_access_token';
  static const _refreshTokenKey = 'carlift_refresh_token';

  ApiClient() : _dio = Dio(BaseOptions(baseUrl: ApiConfig.baseUrl, connectTimeout: const Duration(seconds: 12))) {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final token = prefs.getString(_accessTokenKey);
        if (token != null) options.headers['Authorization'] = 'Bearer $token';
        handler.next(options);
      },
      onError: (error, handler) async {
        // 401 -> attempt one refresh-token retry, mirroring POST /api/auth/refresh
        if (error.response?.statusCode == 401) {
          final prefs = await SharedPreferences.getInstance();
          final refreshToken = prefs.getString(_refreshTokenKey);
          if (refreshToken != null) {
            try {
              final res = await _dio.post('/auth/refresh', data: {'refreshToken': refreshToken});
              final newAccess = res.data['data']['accessToken'] as String;
              await prefs.setString(_accessTokenKey, newAccess);
              final retryReq = error.requestOptions;
              retryReq.headers['Authorization'] = 'Bearer $newAccess';
              final retried = await _dio.fetch(retryReq);
              return handler.resolve(retried);
            } catch (_) {
              await prefs.remove(_accessTokenKey);
              await prefs.remove(_refreshTokenKey);
            }
          }
        }
        handler.next(error);
      },
    ));
  }

  Dio get dio => _dio;

  static Future<void> saveTokens({required String accessToken, required String refreshToken}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessTokenKey, accessToken);
    await prefs.setString(_refreshTokenKey, refreshToken);
  }

  static Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessTokenKey);
    await prefs.remove(_refreshTokenKey);
  }

  static Future<bool> hasSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_accessTokenKey) != null;
  }
}

/// Thrown by repositories on any failure (network, validation, auth) with a
/// message key screens can localize, plus the raw message as a fallback.
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});
  @override
  String toString() => message;
}
