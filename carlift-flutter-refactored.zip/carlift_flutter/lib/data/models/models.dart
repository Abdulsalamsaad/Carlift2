/// Data models. Field names/JSON keys mirror the Prisma backend schema
/// (see the Express project's prisma/schema.prisma) so `fromJson` works
/// unmodified once ApiClient is pointed at a live server.

class AppUser {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String role;
  final String? companyId;
  final String status;
  final String preferredLanguage;
  final Map<String, dynamic>? notificationPreferences;
  final String? emergencyName;
  final String? emergencyPhone;

  AppUser({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.role,
    this.companyId,
    required this.status,
    this.preferredLanguage = 'en',
    this.notificationPreferences,
    this.emergencyName,
    this.emergencyPhone,
  });

  AppUser copyWith({
    String? name,
    String? phone,
    String? email,
    String? preferredLanguage,
    String? emergencyName,
    String? emergencyPhone,
    Map<String, dynamic>? notificationPreferences,
  }) {
    return AppUser(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      role: role,
      companyId: companyId,
      status: status,
      preferredLanguage: preferredLanguage ?? this.preferredLanguage,
      notificationPreferences: notificationPreferences ?? this.notificationPreferences,
      emergencyName: emergencyName ?? this.emergencyName,
      emergencyPhone: emergencyPhone ?? this.emergencyPhone,
    );
  }

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'] as String,
        name: j['name'] as String,
        phone: j['phone'] as String,
        email: j['email'] as String,
        role: j['role'] as String? ?? 'passenger',
        companyId: j['companyId'] as String?,
        status: j['status'] as String? ?? 'active',
        preferredLanguage: j['preferredLanguage'] as String? ?? 'en',
        notificationPreferences: j['notificationPreferences'] as Map<String, dynamic>?,
        emergencyName: j['emergencyName'] as String?,
        emergencyPhone: j['emergencyPhone'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'email': email,
        'role': role,
        'companyId': companyId,
        'status': status,
        'preferredLanguage': preferredLanguage,
        'notificationPreferences': notificationPreferences,
        'emergencyName': emergencyName,
        'emergencyPhone': emergencyPhone,
      };
}

/// One bookable option returned by a route search: a specific company +
/// route + schedule (departure time) + live pricing tiers. Maps to a joined
/// Route+Schedule+Company record from GET /api/routes/search.
class RideOption {
  final String routeId;
  final String scheduleId;
  final String company;
  final String initials;
  final double rating;
  final String originZone;
  final String destinationZone;
  final DateTime departureTime; // exact time, not just a label
  final int durationMinutes;
  final List<String> stops;
  final int seatsLeft;
  final double priceDaily;
  final double priceWeekly;
  final double priceMonthly;
  final String colorHex;
  final String driverName;
  final String driverPhone;
  final String busNumber;

  RideOption({
    required this.routeId,
    required this.scheduleId,
    required this.company,
    required this.initials,
    required this.rating,
    required this.originZone,
    required this.destinationZone,
    required this.departureTime,
    required this.durationMinutes,
    required this.stops,
    required this.seatsLeft,
    required this.priceDaily,
    required this.priceWeekly,
    required this.priceMonthly,
    required this.colorHex,
    required this.driverName,
    required this.driverPhone,
    required this.busNumber,
  });

  double priceForPlan(String plan) {
    switch (plan) {
      case 'weekly':
        return priceWeekly;
      case 'monthly':
        return priceMonthly;
      default:
        return priceDaily;
    }
  }

  factory RideOption.fromJson(Map<String, dynamic> j) => RideOption(
        routeId: j['routeId'] as String,
        scheduleId: j['scheduleId'] as String,
        company: j['company'] as String,
        initials: j['initials'] as String,
        rating: (j['rating'] as num).toDouble(),
        originZone: j['originZone'] as String,
        destinationZone: j['destinationZone'] as String,
        departureTime: DateTime.parse(j['departureTime'] as String),
        durationMinutes: j['durationMinutes'] as int,
        stops: List<String>.from(j['stops'] as List),
        seatsLeft: j['seatsLeft'] as int,
        priceDaily: (j['priceDaily'] as num).toDouble(),
        priceWeekly: (j['priceWeekly'] as num).toDouble(),
        priceMonthly: (j['priceMonthly'] as num).toDouble(),
        colorHex: j['colorHex'] as String? ?? '#16645C',
        driverName: j['driverName'] as String,
        driverPhone: j['driverPhone'] as String,
        busNumber: j['busNumber'] as String,
      );
}

class SearchQuery {
  final String origin;
  final String destination;
  final DateTime? departureTime; // exact time filter (nullable = any time)
  final String frequency; // daily | weekly | monthly

  SearchQuery({required this.origin, required this.destination, this.departureTime, this.frequency = 'monthly'});

  SearchQuery copyWith({String? origin, String? destination, DateTime? departureTime, String? frequency}) => SearchQuery(
        origin: origin ?? this.origin,
        destination: destination ?? this.destination,
        departureTime: departureTime ?? this.departureTime,
        frequency: frequency ?? this.frequency,
      );

  Map<String, String> toQueryParams() => {
        'origin_zone': origin,
        'destination_zone': destination,
        if (departureTime != null) 'departure_time': '${departureTime!.hour.toString().padLeft(2, '0')}:${departureTime!.minute.toString().padLeft(2, '0')}',
        'plan_type': frequency,
      };
}

class ScheduleConfig {
  List<String> days;
  String plan; // daily | weekly | monthly
  bool roundTrip;
  ScheduleConfig({this.days = const ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], this.plan = 'monthly', this.roundTrip = false});
}

class Subscription {
  final String id;
  final String origin;
  final String destination;
  final String company;
  final String initials;
  final String colorHex;
  final String departureLabel;
  final List<String> days;
  final String plan;
  final double price;
  final String paymentMethod;
  String status; // active | cancelled
  final DateTime createdAt;
  final String driverName;
  final String driverPhone;
  final String busNumber;
  List<ChatMessage> messages;

  Subscription({
    required this.id,
    required this.origin,
    required this.destination,
    required this.company,
    required this.initials,
    required this.colorHex,
    required this.departureLabel,
    required this.days,
    required this.plan,
    required this.price,
    required this.paymentMethod,
    required this.status,
    required this.createdAt,
    required this.driverName,
    required this.driverPhone,
    required this.busNumber,
    this.messages = const [],
  });

  factory Subscription.fromJson(Map<String, dynamic> j) => Subscription(
        id: j['id'] as String,
        origin: j['origin'] as String,
        destination: j['destination'] as String,
        company: j['company'] as String,
        initials: j['initials'] as String,
        colorHex: j['colorHex'] as String,
        departureLabel: j['departureLabel'] as String,
        days: List<String>.from(j['days'] as List),
        plan: j['plan'] as String,
        price: (j['price'] as num).toDouble(),
        paymentMethod: j['paymentMethod'] as String,
        status: j['status'] as String,
        createdAt: DateTime.parse(j['createdAt'] as String),
        driverName: j['driverName'] as String,
        driverPhone: j['driverPhone'] as String,
        busNumber: j['busNumber'] as String,
        messages: ((j['messages'] as List?) ?? []).map((m) => ChatMessage.fromJson(m)).toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'origin': origin, 'destination': destination, 'company': company, 'initials': initials,
        'colorHex': colorHex, 'departureLabel': departureLabel, 'days': days, 'plan': plan, 'price': price,
        'paymentMethod': paymentMethod, 'status': status, 'createdAt': createdAt.toIso8601String(),
        'driverName': driverName, 'driverPhone': driverPhone, 'busNumber': busNumber,
        'messages': messages.map((m) => m.toJson()).toList(),
      };
}

class ChatMessage {
  final String from; // 'me' | 'driver'
  final String text;
  final DateTime at;
  ChatMessage({required this.from, required this.text, required this.at});
  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(from: j['from'], text: j['text'], at: DateTime.parse(j['at']));
  Map<String, dynamic> toJson() => {'from': from, 'text': text, 'at': at.toIso8601String()};
}

class FavoriteRoute {
  final String id;
  final String origin;
  final String destination;
  final String company;
  final String initials;
  final String colorHex;
  final String departureLabel;
  final String? routeId;
  final String? scheduleId;

  FavoriteRoute({
    required this.id, required this.origin, required this.destination, required this.company,
    required this.initials, required this.colorHex, required this.departureLabel, this.routeId, this.scheduleId,
  });

  factory FavoriteRoute.fromJson(Map<String, dynamic> j) => FavoriteRoute(
        id: j['id'], origin: j['origin'], destination: j['destination'], company: j['company'],
        initials: j['initials'], colorHex: j['colorHex'], departureLabel: j['departureLabel'],
        routeId: j['routeId'], scheduleId: j['scheduleId'],
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'origin': origin, 'destination': destination, 'company': company, 'initials': initials,
        'colorHex': colorHex, 'departureLabel': departureLabel, 'routeId': routeId, 'scheduleId': scheduleId,
      };
}

class AppNotification {
  final String id;
  final String type; // trip_update | subscription_renewal | promo_announcement | system
  final String title;
  final String body;
  bool isRead;
  final DateTime createdAt;

  AppNotification({required this.id, required this.type, required this.title, required this.body, required this.isRead, required this.createdAt});

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: j['id'], type: j['type'], title: j['title'], body: j['body'], isRead: j['isRead'] as bool, createdAt: DateTime.parse(j['createdAt']),
      );

  Map<String, dynamic> toJson() => {'id': id, 'type': type, 'title': title, 'body': body, 'isRead': isRead, 'createdAt': createdAt.toIso8601String()};
}

/// Mirrors the AdBanner Prisma model.
class AdBanner {
  final String id;
  final String title;
  final String sponsor;
  final String placementZone; // home_hero | search_results | passenger_profile | ticket_screen
  final String? targetUrl;
  final List<String> gradientHex;

  AdBanner({required this.id, required this.title, required this.sponsor, required this.placementZone, this.targetUrl, required this.gradientHex});

  factory AdBanner.fromJson(Map<String, dynamic> j) => AdBanner(
        id: j['id'], title: j['title'], sponsor: j['sponsor'] ?? 'Dubai Carlift', placementZone: j['placementZone'],
        targetUrl: j['targetUrl'], gradientHex: List<String>.from(j['gradientHex'] ?? ['#16645C', '#0B1F2A']),
      );
}
