import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../api_client.dart';
import '../models/models.dart';

// ---------------------------------------------------------------------------
// Favorites — mirrors FavoriteRoute + /api/v1/passenger/favorites
// ---------------------------------------------------------------------------
abstract class FavoritesRepository {
  Future<List<FavoriteRoute>> list();
  Future<void> toggle(RideOption ride);
  Future<void> remove(String id);
}

class MockFavoritesRepository implements FavoritesRepository {
  static const _key = 'carlift_mock_favorites';

  Future<List<FavoriteRoute>> _readAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((j) => FavoriteRoute.fromJson(j)).toList();
  }

  Future<void> _writeAll(List<FavoriteRoute> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((f) => f.toJson()).toList()));
  }

  @override
  Future<List<FavoriteRoute>> list() => _readAll();

  @override
  Future<void> toggle(RideOption ride) async {
    final all = await _readAll();
    final exists = all.where((f) => f.routeId == ride.routeId && f.scheduleId == ride.scheduleId).toList();
    if (exists.isNotEmpty) {
      await _writeAll(all.where((f) => f.id != exists.first.id).toList());
    } else {
      final fav = FavoriteRoute(
        id: 'fav_${DateTime.now().millisecondsSinceEpoch}', origin: ride.originZone, destination: ride.destinationZone,
        company: ride.company, initials: ride.initials, colorHex: ride.colorHex,
        departureLabel: '${ride.departureTime.hour.toString().padLeft(2, '0')}:${ride.departureTime.minute.toString().padLeft(2, '0')}',
        routeId: ride.routeId, scheduleId: ride.scheduleId,
      );
      await _writeAll([fav, ...all]);
    }
  }

  @override
  Future<void> remove(String id) async {
    final all = await _readAll();
    await _writeAll(all.where((f) => f.id != id).toList());
  }
}

class HttpFavoritesRepository implements FavoritesRepository {
  final ApiClient client;
  HttpFavoritesRepository(this.client);

  @override
  Future<List<FavoriteRoute>> list() async {
    final res = await client.dio.get('/v1/passenger/favorites');
    return (res.data['data'] as List).map((j) => FavoriteRoute.fromJson(j)).toList();
  }

  @override
  Future<void> toggle(RideOption ride) async {
    await client.dio.post('/v1/passenger/favorites', data: {'routeId': ride.routeId});
  }

  @override
  Future<void> remove(String id) async {
    await client.dio.delete('/v1/passenger/favorites/$id');
  }
}

// ---------------------------------------------------------------------------
// Notifications — mirrors /api/v1/notifications
// ---------------------------------------------------------------------------
abstract class NotificationsRepository {
  Future<List<AppNotification>> list();
  Future<void> markRead(String id);
  Future<void> markAllRead();
  Future<void> seedWelcome(String titleWelcome, String bodyWelcome, String titlePromo, String bodyPromo);
}

class MockNotificationsRepository implements NotificationsRepository {
  static const _key = 'carlift_mock_notifications';

  Future<List<AppNotification>> _readAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((j) => AppNotification.fromJson(j)).toList();
  }

  Future<void> _writeAll(List<AppNotification> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((n) => n.toJson()).toList()));
  }

  @override
  Future<List<AppNotification>> list() => _readAll();

  @override
  Future<void> markRead(String id) async {
    final all = await _readAll();
    final idx = all.indexWhere((n) => n.id == id);
    if (idx != -1) {
      all[idx].isRead = true;
      await _writeAll(all);
    }
  }

  @override
  Future<void> markAllRead() async {
    final all = await _readAll();
    for (final n in all) {
      n.isRead = true;
    }
    await _writeAll(all);
  }

  @override
  Future<void> seedWelcome(String titleWelcome, String bodyWelcome, String titlePromo, String bodyPromo) async {
    final existing = await _readAll();
    if (existing.isNotEmpty) return;
    await _writeAll([
      AppNotification(id: 'n1', type: 'system', title: titleWelcome, body: bodyWelcome, isRead: false, createdAt: DateTime.now()),
      AppNotification(id: 'n2', type: 'promo_announcement', title: titlePromo, body: bodyPromo, isRead: false, createdAt: DateTime.now()),
    ]);
  }
}

class HttpNotificationsRepository implements NotificationsRepository {
  final ApiClient client;
  HttpNotificationsRepository(this.client);

  @override
  Future<List<AppNotification>> list() async {
    final res = await client.dio.get('/v1/notifications');
    return (res.data['data'] as List).map((j) => AppNotification.fromJson(j)).toList();
  }

  @override
  Future<void> markRead(String id) async {
    await client.dio.patch('/v1/notifications/$id/read');
  }

  @override
  Future<void> markAllRead() async {
    await client.dio.patch('/v1/notifications/read-all');
  }

  @override
  Future<void> seedWelcome(String titleWelcome, String bodyWelcome, String titlePromo, String bodyPromo) async {
    // No-op for the live backend — welcome/promo notifications are sent server-side.
  }
}

// ---------------------------------------------------------------------------
// Ads — mirrors AdBanner + GET /api/v1/ads/active
// ---------------------------------------------------------------------------
abstract class AdsRepository {
  Future<AdBanner?> activeAdFor(String placementZone);
  Future<void> trackClick(String adId);
}

class MockAdsRepository implements AdsRepository {
  static final Map<String, AdBanner> _ads = {
    'home_hero': AdBanner(id: 'ad1', title: 'Ramadan fares — 15% off monthly passes', sponsor: 'Dubai Carlift', placementZone: 'home_hero', gradientHex: ['#16645C', '#0B1F2A']),
    'search_results': AdBanner(id: 'ad2', title: 'Arabia Transit — 20% off your first month', sponsor: 'Arabia Transit', placementZone: 'search_results', gradientHex: ['#E8A33D', '#C6821F']),
    'ticket_screen': AdBanner(id: 'ad3', title: 'Add Tabby to any plan, split in 4', sponsor: 'Tabby', placementZone: 'ticket_screen', gradientHex: ['#132C3A', '#16645C']),
  };

  @override
  Future<AdBanner?> activeAdFor(String placementZone) async => _ads[placementZone];

  @override
  Future<void> trackClick(String adId) async {
    // no-op locally; HttpAdsRepository posts to /api/v1/ads/:id/click
  }
}

class HttpAdsRepository implements AdsRepository {
  final ApiClient client;
  HttpAdsRepository(this.client);

  @override
  Future<AdBanner?> activeAdFor(String placementZone) async {
    final res = await client.dio.get('/v1/ads/active', queryParameters: {'placement': placementZone});
    final list = res.data['data'] as List;
    if (list.isEmpty) return null;
    return AdBanner.fromJson(list.first);
  }

  @override
  Future<void> trackClick(String adId) async {
    await client.dio.post('/v1/ads/$adId/click');
  }
}
