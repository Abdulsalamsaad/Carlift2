import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../api_client.dart';
import '../models/models.dart';

abstract class BookingRepository {
  Future<List<Subscription>> listMySubscriptions();
  Future<Subscription> createSubscription({
    required RideOption ride,
    required ScheduleConfig config,
    required String paymentMethod,
  });
  Future<void> cancelSubscription(String id);
  Future<void> sendDriverMessage(String subscriptionId, String text);
}

class MockBookingRepository implements BookingRepository {
  static const _key = 'carlift_mock_subscriptions';

  Future<List<Subscription>> _readAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((j) => Subscription.fromJson(j)).toList();
  }

  Future<void> _writeAll(List<Subscription> subs) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(subs.map((s) => s.toJson()).toList()));
  }

  @override
  Future<List<Subscription>> listMySubscriptions() => _readAll();

  @override
  Future<Subscription> createSubscription({required RideOption ride, required ScheduleConfig config, required String paymentMethod}) async {
    await Future.delayed(const Duration(milliseconds: 900)); // simulate payment/reservation processing
    final sub = Subscription(
      id: 'sub_${DateTime.now().millisecondsSinceEpoch}',
      origin: ride.originZone, destination: ride.destinationZone, company: ride.company, initials: ride.initials,
      colorHex: ride.colorHex,
      departureLabel: '${ride.departureTime.hour.toString().padLeft(2, '0')}:${ride.departureTime.minute.toString().padLeft(2, '0')}',
      days: config.days, plan: config.plan, price: ride.priceForPlan(config.plan), paymentMethod: paymentMethod,
      status: 'active', createdAt: DateTime.now(), driverName: ride.driverName, driverPhone: ride.driverPhone,
      busNumber: ride.busNumber, messages: const [],
    );
    final all = await _readAll();
    await _writeAll([sub, ...all]);
    return sub;
  }

  @override
  Future<void> cancelSubscription(String id) async {
    final all = await _readAll();
    final idx = all.indexWhere((s) => s.id == id);
    if (idx == -1) throw ApiException('not_found');
    all[idx].status = 'cancelled';
    await _writeAll(all);
  }

  @override
  Future<void> sendDriverMessage(String subscriptionId, String text) async {
    final all = await _readAll();
    final idx = all.indexWhere((s) => s.id == subscriptionId);
    if (idx == -1) throw ApiException('not_found');
    all[idx].messages = [...all[idx].messages, ChatMessage(from: 'me', text: text, at: DateTime.now())];
    await _writeAll(all);
    // Simulate a short auto-reply so the thread feels alive in demo/offline mode.
    await Future.delayed(const Duration(milliseconds: 1100));
    final refreshed = await _readAll();
    final idx2 = refreshed.indexWhere((s) => s.id == subscriptionId);
    if (idx2 != -1) {
      refreshed[idx2].messages = [...refreshed[idx2].messages, ChatMessage(from: 'driver', text: '👍', at: DateTime.now())];
      await _writeAll(refreshed);
    }
  }
}

/// Real backend implementation — POST/GET/PATCH /api/subscriptions,
/// and a lightweight driver-messaging endpoint you'll want to add
/// (e.g. POST /api/subscriptions/:id/messages backed by a websocket or
/// push-notification relay in production; REST polling as a fallback).
class HttpBookingRepository implements BookingRepository {
  final ApiClient client;
  HttpBookingRepository(this.client);

  @override
  Future<List<Subscription>> listMySubscriptions() async {
    final res = await client.dio.get('/subscriptions');
    return (res.data['data'] as List).map((j) => Subscription.fromJson(j)).toList();
  }

  @override
  Future<Subscription> createSubscription({required RideOption ride, required ScheduleConfig config, required String paymentMethod}) async {
    final res = await client.dio.post('/subscriptions', data: {
      'routeId': ride.routeId, 'scheduleId': ride.scheduleId, 'planType': config.plan,
      'selectedWorkdays': config.days, 'paymentMethod': paymentMethod,
    });
    return Subscription.fromJson(res.data['data']);
  }

  @override
  Future<void> cancelSubscription(String id) async {
    await client.dio.patch('/subscriptions/$id', data: {'status': 'cancelled'});
  }

  @override
  Future<void> sendDriverMessage(String subscriptionId, String text) async {
    await client.dio.post('/subscriptions/$subscriptionId/messages', data: {'text': text});
  }
}
