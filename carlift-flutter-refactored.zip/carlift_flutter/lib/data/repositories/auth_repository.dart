import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../api_client.dart';
import '../models/models.dart';

abstract class AuthRepository {
  Future<AppUser?> restoreSession();
  Future<AppUser> register({required String name, required String phone, required String email, required String password});
  Future<AppUser> login({required String email, required String password});
  Future<AppUser> updateProfile(AppUser updated);
  Future<void> logout();
}

/// Fully functional local implementation — persists to SharedPreferences so
/// accounts/edits survive app restarts, without requiring a live backend.
/// This is what main.dart wires up by default (AppConfig.useMockData = true).
class MockAuthRepository implements AuthRepository {
  static const _profileKey = 'carlift_mock_profile';

  @override
  Future<AppUser?> restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_profileKey);
    if (raw == null) return null;
    return AppUser.fromJson(jsonDecode(raw));
  }

  @override
  Future<AppUser> register({required String name, required String phone, required String email, required String password}) async {
    await Future.delayed(const Duration(milliseconds: 500)); // simulate network latency
    final user = AppUser(
      id: 'local_${DateTime.now().millisecondsSinceEpoch}',
      name: name, phone: phone, email: email, role: 'passenger', status: 'active', preferredLanguage: 'en',
      notificationPreferences: {'push': true, 'sms': false, 'promo': true},
    );
    await _persist(user);
    return user;
  }

  @override
  Future<AppUser> login({required String email, required String password}) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_profileKey);
    if (raw == null) throw ApiException('errorInvalidCredentials');
    final user = AppUser.fromJson(jsonDecode(raw));
    if (user.email.toLowerCase() != email.toLowerCase()) throw ApiException('errorInvalidCredentials');
    return user; // mock: no real password check locally (there's nothing to check against)
  }

  @override
  Future<AppUser> updateProfile(AppUser updated) async {
    await _persist(updated);
    return updated;
  }

  @override
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_profileKey);
  }

  Future<void> _persist(AppUser user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_profileKey, jsonEncode(user.toJson()));
  }
}

/// Real backend implementation — hits the Express API's
/// POST /api/auth/register, /api/auth/login, /api/auth/refresh, GET /api/auth/me,
/// PATCH /api/v1/passenger/profile. Wire this in once ApiConfig.baseUrl points
/// at your deployed server.
class HttpAuthRepository implements AuthRepository {
  final ApiClient client;
  HttpAuthRepository(this.client);

  @override
  Future<AppUser?> restoreSession() async {
    if (!await ApiClient.hasSession()) return null;
    try {
      final res = await client.dio.get('/auth/me');
      return AppUser.fromJson(res.data['data']);
    } catch (_) {
      await ApiClient.clearTokens();
      return null;
    }
  }

  @override
  Future<AppUser> register({required String name, required String phone, required String email, required String password}) async {
    try {
      final res = await client.dio.post('/auth/register', data: {
        'name': name, 'phone': phone, 'email': email, 'password': password, 'role': 'passenger',
      });
      final data = res.data['data'];
      await ApiClient.saveTokens(accessToken: data['accessToken'], refreshToken: data['refreshToken']);
      return AppUser.fromJson(data['user']);
    } on Exception catch (e) {
      throw ApiException(e.toString());
    }
  }

  @override
  Future<AppUser> login({required String email, required String password}) async {
    try {
      final res = await client.dio.post('/auth/login', data: {'email': email, 'password': password});
      final data = res.data['data'];
      await ApiClient.saveTokens(accessToken: data['accessToken'], refreshToken: data['refreshToken']);
      return AppUser.fromJson(data['user']);
    } on Exception catch (e) {
      throw ApiException('errorInvalidCredentials');
    }
  }

  @override
  Future<AppUser> updateProfile(AppUser updated) async {
    final res = await client.dio.patch('/v1/passenger/profile', data: {
      'name': updated.name, 'phone': updated.phone, 'email': updated.email,
      'emergencyName': updated.emergencyName, 'emergencyPhone': updated.emergencyPhone,
    });
    await client.dio.patch('/v1/passenger/settings', data: {'preferredLanguage': updated.preferredLanguage});
    return AppUser.fromJson(res.data['data']);
  }

  @override
  Future<void> logout() async {
    await ApiClient.clearTokens();
  }
}
