import '../api_client.dart';
import '../models/models.dart';

abstract class SearchRepository {
  Future<List<RideOption>> search(SearchQuery query);
  Future<List<String>> pickupZones();
  Future<List<String>> destinationZones();
}

/// In-memory ride catalog with genuine filtering logic — this is not a static
/// dump: it actually filters by origin, destination, a departure-time window,
/// and which plan tiers the schedule sells, mirroring what
/// GET /api/routes/search would do server-side (see backend addendum).
class MockSearchRepository implements SearchRepository {
  static final List<RideOption> _catalog = [
    RideOption(
      routeId: 'route_1', scheduleId: 'sched_1', company: 'Arabia Transit', initials: 'AR', rating: 4.8,
      originZone: 'Satwa', destinationZone: 'Dubai Marina', departureTime: DateTime(2026, 1, 1, 7, 15),
      durationMinutes: 35, stops: const ['Satwa Rbt', 'Al Wasl Rd', 'Marina Mall'], seatsLeft: 4,
      priceDaily: 15, priceWeekly: 70, priceMonthly: 250, colorHex: '#16645C',
      driverName: 'Ahmed R.', driverPhone: '+971 50 123 4567', busNumber: '-114',
    ),
    RideOption(
      routeId: 'route_1', scheduleId: 'sched_2', company: 'Arabia Transit', initials: 'AR', rating: 4.8,
      originZone: 'Satwa', destinationZone: 'Dubai Marina', departureTime: DateTime(2026, 1, 1, 8, 30),
      durationMinutes: 35, stops: const ['Satwa Rbt', 'Al Wasl Rd', 'Marina Mall'], seatsLeft: 6,
      priceDaily: 15, priceWeekly: 70, priceMonthly: 250, colorHex: '#16645C',
      driverName: 'Ahmed R.', driverPhone: '+971 50 123 4567', busNumber: '-114',
    ),
    RideOption(
      routeId: 'route_2', scheduleId: 'sched_3', company: 'Nawaz Carlift', initials: 'NW', rating: 4.6,
      originZone: 'Satwa', destinationZone: 'Dubai Marina', departureTime: DateTime(2026, 1, 1, 7, 45),
      durationMinutes: 40, stops: const ['Satwa Sq', 'Jumeirah Rd', 'JBR Walk'], seatsLeft: 2,
      priceDaily: 14, priceWeekly: 65, priceMonthly: 235, colorHex: '#E8A33D',
      driverName: 'Yousef K.', driverPhone: '+971 52 987 6543', busNumber: '-207',
    ),
    RideOption(
      routeId: 'route_3', scheduleId: 'sched_4', company: 'Anazik Mobility', initials: 'AZ', rating: 4.9,
      originZone: 'Satwa', destinationZone: 'Dubai Marina', departureTime: DateTime(2026, 1, 1, 8, 0),
      durationMinutes: 30, stops: const ['Satwa Metro', 'Marina Mall'], seatsLeft: 9,
      priceDaily: 16, priceWeekly: 75, priceMonthly: 260, colorHex: '#C4432B',
      driverName: 'Rashid M.', driverPhone: '+971 55 456 7890', busNumber: '-332',
    ),
    RideOption(
      routeId: 'route_4', scheduleId: 'sched_5', company: 'Nawaz Carlift', initials: 'NW', rating: 4.6,
      originZone: 'Karama', destinationZone: 'JBR', departureTime: DateTime(2026, 1, 1, 7, 30),
      durationMinutes: 42, stops: const ['Karama Centre', 'Sheikh Zayed Rd', 'JBR Beach'], seatsLeft: 5,
      priceDaily: 17, priceWeekly: 78, priceMonthly: 270, colorHex: '#E8A33D',
      driverName: 'Yousef K.', driverPhone: '+971 52 987 6543', busNumber: '-208',
    ),
  ];

  @override
  Future<List<RideOption>> search(SearchQuery query) async {
    await Future.delayed(const Duration(milliseconds: 450)); // simulate a real network round-trip
    return _catalog.where((r) {
      final matchesRoute = r.originZone == query.origin && r.destinationZone == query.destination;
      if (!matchesRoute) return false;

      if (query.departureTime != null) {
        // Match within a 90-minute window of the requested departure time —
        // a flight-style search shows nearby options, not just an exact minute.
        final requestedMinutes = query.departureTime!.hour * 60 + query.departureTime!.minute;
        final rideMinutes = r.departureTime.hour * 60 + r.departureTime.minute;
        if ((requestedMinutes - rideMinutes).abs() > 90) return false;
      }
      return true; // all seeded schedules sell daily/weekly/monthly, so frequency doesn't filter further here
    }).toList()
      ..sort((a, b) => a.departureTime.compareTo(b.departureTime));
  }

  @override
  Future<List<String>> pickupZones() async => ['Satwa', 'Karama', 'Bur Dubai', 'Al Rigga', 'Al Qusais', 'International City'];

  @override
  Future<List<String>> destinationZones() async => ['Dubai Mall', 'Dubai Marina', 'JBR', 'JLT', 'Dubai Hills', 'Business Bay'];
}

/// Real backend implementation — GET /api/routes/search?origin_zone=&destination_zone=&departure_time=&plan_type=
/// (new endpoint; see backend addendum in the accompanying README for the controller/route code).
class HttpSearchRepository implements SearchRepository {
  final ApiClient client;
  HttpSearchRepository(this.client);

  @override
  Future<List<RideOption>> search(SearchQuery query) async {
    try {
      final res = await client.dio.get('/routes/search', queryParameters: query.toQueryParams());
      return (res.data['data'] as List).map((j) => RideOption.fromJson(j)).toList();
    } on Exception catch (e) {
      throw ApiException(e.toString());
    }
  }

  @override
  Future<List<String>> pickupZones() async {
    final res = await client.dio.get('/routes/zones', queryParameters: {'type': 'origin'});
    return List<String>.from(res.data['data']);
  }

  @override
  Future<List<String>> destinationZones() async {
    final res = await client.dio.get('/routes/zones', queryParameters: {'type': 'destination'});
    return List<String>.from(res.data['data']);
  }
}
