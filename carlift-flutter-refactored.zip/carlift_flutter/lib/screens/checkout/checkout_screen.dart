import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import '../rides/pass_detail_screen.dart';

bool _luhnValid(String num) {
  final digits = num.replaceAll(' ', '');
  if (!RegExp(r'^\d{16}$').hasMatch(digits)) return false;
  var sum = 0;
  var alt = false;
  for (var i = digits.length - 1; i >= 0; i--) {
    var n = int.parse(digits[i]);
    if (alt) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
    alt = !alt;
  }
  return sum % 10 == 0;
}

bool _expiryValid(String mmYY) {
  final m = RegExp(r'^(\d{2})/(\d{2})$').firstMatch(mmYY);
  if (m == null) return false;
  final month = int.parse(m.group(1)!);
  final year = 2000 + int.parse(m.group(2)!);
  if (month < 1 || month > 12) return false;
  final expiry = DateTime(year, month + 1, 0, 23, 59);
  return expiry.isAfter(DateTime.now());
}

class CheckoutScreen extends StatefulWidget {
  final RideOption ride;
  final ScheduleConfig config;
  const CheckoutScreen({super.key, required this.ride, required this.config});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String method = 'tabby';
  final _cardNumber = TextEditingController();
  final _expiry = TextEditingController();
  final _cvc = TextEditingController();
  String? _cardError, _expiryError, _cvcError;
  bool _submitting = false;

  bool _validateCard() {
    setState(() {
      _cardError = _luhnValid(_cardNumber.text) ? null : ' ';
      _expiryError = _expiryValid(_expiry.text) ? null : ' ';
      _cvcError = RegExp(r'^\d{3}$').hasMatch(_cvc.text) ? null : ' ';
    });
    return _cardError == null && _expiryError == null && _cvcError == null;
  }

  Future<void> _submit() async {
    if (method == 'card' && !_validateCard()) return;
    setState(() => _submitting = true);
    final sub = await context.read<BookingProvider>().book(ride: widget.ride, config: widget.config, paymentMethod: method);
    setState(() => _submitting = false);
    if (mounted) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => PassDetailScreen(subscriptionId: sub.id)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final ride = widget.ride;
    final config = widget.config;
    final price = ride.priceForPlan(config.plan);
    final installment = (price / 4);

    return Scaffold(
      appBar: AppBar(title: Text(t.checkoutTitle)),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      RouteBadge(from: ride.originZone, to: ride.destinationZone),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: AppColors.goldTint, borderRadius: BorderRadius.circular(999)),
                        child: Text(config.plan.toUpperCase(), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.goldDeep)),
                      ),
                    ]),
                    const Divider(height: 20),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Expanded(child: Text('${ride.company} · ${config.days.join(", ")}', style: const TextStyle(fontSize: 12, color: AppColors.muted))),
                      Text('AED ${price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.navy)),
                    ]),
                  ]),
                ),
                const SizedBox(height: 20),
                Text(t.paymentMethod, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: _MethodTile(icon: Icons.account_balance_wallet_rounded, label: t.tabby, active: method == 'tabby', onTap: () => setState(() => method = 'tabby'))),
                  const SizedBox(width: 8),
                  Expanded(child: _MethodTile(icon: Icons.credit_card_rounded, label: t.card, active: method == 'card', onTap: () => setState(() => method = 'card'))),
                  const SizedBox(width: 8),
                  Expanded(child: _MethodTile(icon: Icons.payments_rounded, label: t.cash, active: method == 'cash', onTap: () => setState(() => method = 'cash'))),
                ]),
                const SizedBox(height: 16),
                if (method == 'tabby') _TabbyPanel(installment: installment, t: t),
                if (method == 'card')
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                    child: Column(children: [
                      AppField(label: t.cardNumber, controller: _cardNumber, error: _cardError, keyboardType: TextInputType.number, maxLength: 19),
                      const SizedBox(height: 10),
                      Row(children: [
                        Expanded(child: AppField(label: t.expiry, controller: _expiry, error: _expiryError, keyboardType: TextInputType.number, maxLength: 5)),
                        const SizedBox(width: 10),
                        Expanded(child: AppField(label: t.cvc, controller: _cvc, error: _cvcError, keyboardType: TextInputType.number, maxLength: 3)),
                      ]),
                    ]),
                  ),
                if (method == 'cash')
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.goldTint, border: Border.all(color: const Color(0xFFEEDBAF)), borderRadius: BorderRadius.circular(16)),
                    child: Text('${ride.company}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.goldDeep)),
                  ),
                const SizedBox(height: 16),
                const AdBannerWidget(placementZone: 'ticket_screen'),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.line))),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _submitting ? null : _submit,
                child: _submitting
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.navy))
                    : Text(method == 'cash' ? t.reserveSeat : t.payButton((method == 'tabby' ? installment : price).toStringAsFixed(2))),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MethodTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _MethodTile({required this.icon, required this.label, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(color: active ? AppColors.navy : Colors.white, border: Border.all(color: active ? AppColors.navy : AppColors.line), borderRadius: BorderRadius.circular(14)),
        child: Column(children: [
          Icon(icon, size: 18, color: active ? Colors.white : AppColors.muted),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.muted)),
        ]),
      ),
    );
  }
}

class _TabbyPanel extends StatelessWidget {
  final double installment;
  final AppLocalizations t;
  const _TabbyPanel({required this.installment, required this.t});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t.splitPayments, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: List.generate(4, (i) {
          final isFirst = i == 0;
          return Column(children: [
            CircleAvatar(radius: 15, backgroundColor: isFirst ? AppColors.gold : AppColors.sand, child: Text('${i + 1}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: isFirst ? AppColors.navy : AppColors.muted))),
            const SizedBox(height: 4),
            Text('AED ${installment.toStringAsFixed(2)}', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          ]);
        })),
        const SizedBox(height: 10),
        Text(t.firstPaymentNote, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
      ]),
    );
  }
}
