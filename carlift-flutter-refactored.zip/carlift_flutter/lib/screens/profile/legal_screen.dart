import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';

// Mirrors GET /api/v1/content/legal — localized per LegalDocument.type.
const _legalDocs = {
  'privacy_policy': {
    'en': 'We collect only the data needed to operate your commute subscriptions and comply with UAE RTA regulations. Your location is only used while tracking an active trip.',
    'ar': 'نجمع فقط البيانات اللازمة لتشغيل اشتراكات التنقل الخاصة بك والامتثال للوائح هيئة الطرق والمواصلات. يُستخدم موقعك فقط أثناء تتبع رحلة نشطة.',
    'ur': 'ہم صرف وہ ڈیٹا اکٹھا کرتے ہیں جو آپ کی سفری سبسکرپشنز چلانے اور UAE RTA ضوابط کی تعمیل کے لیے ضروری ہے۔',
  },
  'terms_of_service': {
    'en': 'By using Carlift you agree to our subscription, cancellation, and refund terms. Passes are non-transferable between passengers.',
    'ar': 'باستخدامك لـ Carlift فإنك توافق على شروط الاشتراك والإلغاء والاسترداد. البطاقات غير قابلة للتحويل بين الركاب.',
    'ur': 'Carlift استعمال کرکے آپ ہماری سبسکرپشن، منسوخی، اور رقم کی واپسی کی شرائط سے متفق ہیں۔',
  },
  'company_info': {
    'en': 'Carlift Transit Platform operates licensed carpooling/carlift services in Dubai in coordination with the RTA.',
    'ar': 'تدير منصة Carlift خدمات النقل التشاركي المرخصة في دبي بالتنسيق مع هيئة الطرق والمواصلات.',
    'ur': 'Carlift Transit Platform دبئی میں RTA کے ساتھ مل کر لائسنس یافتہ کارپولنگ سروسز چلاتا ہے۔',
  },
};

class LegalScreen extends StatefulWidget {
  const LegalScreen({super.key});
  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen> {
  String _tab = 'privacy_policy';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final locale = Localizations.localeOf(context).languageCode;
    final content = _legalDocs[_tab]![locale] ?? _legalDocs[_tab]!['en']!;

    return Scaffold(
      appBar: AppBar(title: Text(t.legalTitle)),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            SelectPill(label: t.privacyPolicy, active: _tab == 'privacy_policy', onTap: () => setState(() => _tab = 'privacy_policy')),
            const SizedBox(width: 8),
            SelectPill(label: t.termsOfService, active: _tab == 'terms_of_service', onTap: () => setState(() => _tab = 'terms_of_service')),
            const SizedBox(width: 8),
            SelectPill(label: t.companyInfo, active: _tab == 'company_info', onTap: () => setState(() => _tab = 'company_info')),
          ]),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                child: Text(content, style: const TextStyle(fontSize: 13, height: 1.6, color: AppColors.text)),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
