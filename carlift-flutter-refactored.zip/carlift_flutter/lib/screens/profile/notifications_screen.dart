import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<NotificationsProvider>().load());
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final notifs = context.watch<NotificationsProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(t.notificationsTitle),
        actions: [
          if (notifs.unreadCount > 0)
            TextButton(onPressed: () => context.read<NotificationsProvider>().markAllRead(), child: Text(t.markAllRead, style: const TextStyle(color: AppColors.gold))),
        ],
      ),
      body: notifs.notifications.isEmpty
          ? Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.notifications_none_rounded, size: 26, color: AppColors.muted),
                const SizedBox(height: 10),
                Text(t.noNotifications, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              ]),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: notifs.notifications.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final n = notifs.notifications[i];
                return InkWell(
                  onTap: () => context.read<NotificationsProvider>().markRead(n.id),
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: n.isRead ? Colors.white : AppColors.goldTint,
                      border: Border.all(color: n.isRead ? AppColors.line : const Color(0xFFEEDBAF)),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(n.type.toUpperCase().replaceAll('_', ' '), style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: AppColors.teal, letterSpacing: 0.5)),
                          const SizedBox(height: 4),
                          Text(n.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                          const SizedBox(height: 2),
                          Text(n.body, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                        ]),
                      ),
                      if (!n.isRead) Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.brick, shape: BoxShape.circle)),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}
