import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../l10n/app_localizations.dart';

const _languages = [
  {'code': 'en', 'native': 'English', 'label': 'English'},
  {'code': 'ar', 'native': 'العربية', 'label': 'Arabic'},
  {'code': 'ur', 'native': 'اردو', 'label': 'Urdu'},
  {'code': 'ne', 'native': 'नेपाली', 'label': 'Nepali'},
  {'code': 'tl', 'native': 'Tagalog', 'label': 'Filipino'},
  {'code': 'bn', 'native': 'বাংলা', 'label': 'Bengali'},
];

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(t.languageTitle)),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _languages.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final l = _languages[i];
          final selected = auth.user?.preferredLanguage == l['code'];
          return Material(
            color: Colors.white,
            child: ListTile(
              title: Text(l['native']!, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(l['label']!, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
              trailing: selected ? const Icon(Icons.check_rounded, color: AppColors.teal) : null,
              onTap: () => context.read<AuthProvider>().setLanguage(l['code']!),
            ),
          );
        },
      ),
    );
  }
}
