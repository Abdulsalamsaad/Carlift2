import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import '../schedule/schedule_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<FavoritesProvider>().load());
  }

  Future<void> _bookAgain(BuildContext context, String? routeId, String? scheduleId) async {
    // Re-run a real search to fetch a live RideOption for this favorite, so
    // Book Again reflects current seats/pricing rather than a stale snapshot.
    final repo = context.read<SearchProvider>();
    final ride = repo.results.where((r) => r.routeId == routeId && r.scheduleId == scheduleId).firstOrNull;
    if (ride != null) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => ScheduleScreen(ride: ride)));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Search again to refresh pricing for this route')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final favorites = context.watch<FavoritesProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(t.favoritesTitle)),
      body: favorites.favorites.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.favorite_border_rounded, size: 28, color: AppColors.muted),
                  const SizedBox(height: 12),
                  Text(t.noFavorites, style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(t.noFavoritesSubtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: favorites.favorites.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final f = favorites.favorites[i];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                  child: Row(children: [
                    CircleAvatar(radius: 18, backgroundColor: hexToColor(f.colorHex), child: Text(f.initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        RouteBadge(from: f.origin, to: f.destination),
                        Text('${f.company} · ${f.departureLabel}', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                      ]),
                    ),
                    Column(children: [
                      TextButton(onPressed: () => _bookAgain(context, f.routeId, f.scheduleId), child: Text(t.bookAgain, style: const TextStyle(fontSize: 11))),
                      IconButton(onPressed: () => context.read<FavoritesProvider>().remove(f.id), icon: const Icon(Icons.favorite_rounded, color: AppColors.brick, size: 18)),
                    ]),
                  ]),
                );
              },
            ),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
