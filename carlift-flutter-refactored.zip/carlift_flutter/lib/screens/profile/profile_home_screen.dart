import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import 'edit_profile_screen.dart';
import 'language_screen.dart';
import 'favorites_screen.dart';
import 'notifications_screen.dart';
import 'faq_screen.dart';
import 'legal_screen.dart';

class ProfileHomeScreen extends StatelessWidget {
  const ProfileHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final auth = context.watch<AuthProvider>();
    final booking = context.watch<BookingProvider>();
    final notifications = context.watch<NotificationsProvider>();
    final user = auth.user!;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Column(children: [
          CircleAvatar(radius: 32, backgroundColor: AppColors.navy, child: Text(user.name.isNotEmpty ? user.name.substring(0, 1).toUpperCase() : '?', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 10),
          Text(user.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
          Text('${booking.subscriptions.length} rides', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]),
        const SizedBox(height: 20),
        _MenuGroup(children: [
          _MenuRow(icon: Icons.person_rounded, label: t.editProfile, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EditProfileScreen()))),
          _MenuRow(icon: Icons.language_rounded, label: t.languageTitle, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LanguageScreen())),
              trailing: Text(_languageNative(user.preferredLanguage), style: const TextStyle(fontSize: 12, color: AppColors.muted))),
          _MenuRow(icon: Icons.favorite_border_rounded, label: t.favoritesTitle, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FavoritesScreen()))),
          _MenuRow(icon: Icons.notifications_none_rounded, label: t.notificationsTitle, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
              trailing: notifications.unreadCount > 0
                  ? Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: AppColors.brick, borderRadius: BorderRadius.circular(999)),
                      child: Text('${notifications.unreadCount}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)))
                  : null),
        ]),
        const SizedBox(height: 12),
        _MenuGroup(children: [
          _MenuRow(icon: Icons.help_outline_rounded, label: t.faqTitle, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FaqScreen()))),
          _MenuRow(icon: Icons.description_outlined, label: t.legalTitle, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LegalScreen()))),
        ]),
        const SizedBox(height: 12),
        _MenuGroup(children: [
          _MenuRow(
            icon: Icons.logout_rounded, label: t.logout, danger: true,
            onTap: () => showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: Text(t.logout),
                content: Text(t.logoutConfirmation),
                actions: [
                  TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(t.staySignedIn)),
                  TextButton(
                    onPressed: () async {
                      Navigator.of(context).pop();
                      await context.read<AuthProvider>().logout();
                    },
                    child: Text(t.logoutButton, style: const TextStyle(color: AppColors.brick)),
                  ),
                ],
              ),
            ),
          ),
        ]),
        const SizedBox(height: 16),
        const AdBannerWidget(placementZone: 'passenger_profile'),
      ]),
    );
  }

  String _languageNative(String code) => const {'en': 'English', 'ar': 'العربية', 'ur': 'اردو', 'ne': 'नेपाली', 'tl': 'Tagalog', 'bn': 'বাংলা'}[code] ?? code;
}

class _MenuGroup extends StatelessWidget {
  final List<Widget> children;
  const _MenuGroup({required this.children});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
        child: Column(children: List.generate(children.length * 2 - 1, (i) => i.isEven ? children[i ~/ 2] : const Divider(height: 1))),
      );
}

class _MenuRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;
  final Widget? trailing;
  const _MenuRow({required this.icon, required this.label, required this.onTap, this.danger = false, this.trailing});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: danger ? AppColors.brick : AppColors.muted, size: 20),
      title: Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: danger ? AppColors.brick : AppColors.text)),
      trailing: trailing ?? const Icon(Icons.chevron_right_rounded, color: AppColors.muted, size: 18),
      onTap: onTap,
    );
  }
}
