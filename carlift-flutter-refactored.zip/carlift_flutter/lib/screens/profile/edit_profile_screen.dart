import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController _name;
  late TextEditingController _phone;
  late TextEditingController _email;
  late TextEditingController _emergName;
  late TextEditingController _emergPhone;
  String? _nameErr, _phoneErr;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    final u = context.read<AuthProvider>().user!;
    _name = TextEditingController(text: u.name);
    _phone = TextEditingController(text: u.phone);
    _email = TextEditingController(text: u.email);
    _emergName = TextEditingController(text: u.emergencyName ?? '');
    _emergPhone = TextEditingController(text: u.emergencyPhone ?? '');
  }

  Future<void> _save() async {
    final t = AppLocalizations.of(context)!;
    setState(() {
      _nameErr = _name.text.trim().length >= 2 ? null : t.errorRequired;
      _phoneErr = _phone.text.replaceAll(RegExp(r'\D'), '').length >= 7 ? null : t.errorRequired;
    });
    if (_nameErr != null || _phoneErr != null) return;

    final auth = context.read<AuthProvider>();
    await auth.updateProfile(auth.user!.copyWith(
      name: _name.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(),
      emergencyName: _emergName.text.trim(), emergencyPhone: _emergPhone.text.trim(),
    ));
    setState(() => _saved = true);
    Future.delayed(const Duration(milliseconds: 1600), () { if (mounted) setState(() => _saved = false); });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.editProfile)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
            child: Column(children: [
              AppField(label: t.fullName, controller: _name, error: _nameErr),
              const SizedBox(height: 12),
              AppField(label: t.phoneNumber, controller: _phone, error: _phoneErr, keyboardType: TextInputType.phone),
              const SizedBox(height: 12),
              AppField(label: t.email, controller: _email, keyboardType: TextInputType.emailAddress),
            ]),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.shield_moon_rounded, size: 15, color: AppColors.brick),
                const SizedBox(width: 6),
                Text(t.emergencyContact, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ]),
              const SizedBox(height: 10),
              AppField(label: t.emergencyName, controller: _emergName),
              const SizedBox(height: 12),
              AppField(label: t.emergencyPhone, controller: _emergPhone, keyboardType: TextInputType.phone),
            ]),
          ),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: ElevatedButton(onPressed: _save, child: Text(_saved ? '${t.savedConfirmation} ✓' : t.saveChanges))),
        ],
      ),
    );
  }
}
