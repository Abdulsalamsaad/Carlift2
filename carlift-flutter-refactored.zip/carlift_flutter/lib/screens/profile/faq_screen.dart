import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../l10n/app_localizations.dart';

// Mirrors GET /api/v1/content/faq — localized {en, ar, ur, ne, tl, bn} per item.
const _faqData = {
  'booking': [
    {
      'q': {'en': 'How do I book a daily commute pass?', 'ar': 'كيف أحجز اشتراك تنقل يومي؟', 'ur': 'میں روزانہ سفر کا پاس کیسے بک کروں؟', 'ne': 'म कसरी दैनिक यात्रा पास बुक गर्न सक्छु?', 'tl': 'Paano ako mag-book ng araw-araw na pass?', 'bn': 'আমি কীভাবে দৈনিক যাতায়াতের পাস বুক করব?'},
      'a': {'en': 'Search your pickup and destination zones, pick a company and exact departure time, choose your working days and plan, then pay.', 'ar': 'ابحث عن منطقتي الانطلاق والوجهة، اختر شركة ووقت انطلاق دقيق، حدد أيام العمل والخطة، ثم ادفع.', 'ur': 'اپنا پک اپ اور منزل کا زون تلاش کریں، کمپنی اور روانگی کا وقت منتخب کریں، کام کے دن اور پلان چنیں، پھر ادائیگی کریں۔', 'ne': 'तपाईंको पिकअप र गन्तव्य क्षेत्र खोज्नुहोस्, कम्पनी र प्रस्थान समय छान्नुहोस्, कामको दिन र योजना छान्नुहोस्, त्यसपछि भुक्तानी गर्नुहोस्।', 'tl': 'Hanapin ang lugar ng pagsakay at destinasyon, pumili ng kumpanya at oras ng alis, piliin ang araw ng trabaho at plano, tapos magbayad.', 'bn': 'আপনার পিকআপ এবং গন্তব্য জোন খুঁজুন, একটি কোম্পানি এবং সঠিক যাত্রার সময় নির্বাচন করুন, কর্মদিবস এবং প্ল্যান বেছে নিন, তারপর পরিশোধ করুন।'},
    },
  ],
  'payments': [
    {
      'q': {'en': 'What payment methods are supported?', 'ar': 'ما هي طرق الدفع المتاحة؟', 'ur': 'کون سے ادائیگی کے طریقے دستیاب ہیں؟', 'ne': 'कुन भुक्तानी विधिहरू समर्थित छन्?', 'tl': 'Anong mga paraan ng bayad ang suportado?', 'bn': 'কোন পেমেন্ট পদ্ধতি সমর্থিত?'},
      'a': {'en': 'Tabby installments, credit/debit card, or cash paid directly to the driver.', 'ar': 'أقساط تابي، بطاقة ائتمان/خصم، أو نقدًا مباشرة للسائق.', 'ur': 'ٹیبی اقساط، کریڈٹ/ڈیبٹ کارڈ، یا ڈرائیور کو براہ راست نقد۔', 'ne': 'ट्याबी किस्ता, क्रेडिट/डेबिट कार्ड, वा चालकलाई सिधै नगद।', 'tl': 'Tabby installments, credit/debit card, o cash na direkta sa driver.', 'bn': 'ট্যাবি কিস্তি, ক্রেডিট/ডেবিট কার্ড, বা সরাসরি চালককে নগদ।'},
    },
  ],
  'subscriptions': [
    {
      'q': {'en': 'Can I cancel anytime?', 'ar': 'هل يمكنني الإلغاء في أي وقت؟', 'ur': 'کیا میں کسی بھی وقت منسوخ کر سکتا ہوں؟', 'ne': 'के म जुनसुकै बेला रद्द गर्न सक्छु?', 'tl': 'Pwede ba akong kumansela anumang oras?', 'bn': 'আমি কি যেকোনো সময় বাতিল করতে পারি?'},
      'a': {'en': 'Yes — open My Rides, select your pass, and tap Cancel this ride.', 'ar': 'نعم — افتح رحلاتي، اختر بطاقتك، واضغط إلغاء هذه الرحلة.', 'ur': 'ہاں — میری رائیڈز کھولیں، اپنا پاس منتخب کریں، اور یہ رائیڈ منسوخ کریں پر ٹیپ کریں۔', 'ne': 'हो — मेरा यात्रा खोल्नुहोस्, आफ्नो पास छान्नुहोस्, र यो यात्रा रद्द गर्नुहोस् थिच्नुहोस्।', 'tl': 'Oo — buksan ang Mga Biyahe Ko, piliin ang iyong pass, at i-tap ang Kanselahin ang biyaheng ito.', 'bn': 'হ্যাঁ — আমার রাইড খুলুন, আপনার পাস নির্বাচন করুন এবং এই রাইড বাতিল করুন ট্যাপ করুন।'},
    },
  ],
};

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final locale = Localizations.localeOf(context).languageCode;

    return Scaffold(
      appBar: AppBar(title: Text(t.faqTitle)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: _faqData.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(entry.key.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.muted, letterSpacing: 0.5)),
                const SizedBox(height: 8),
                Container(
                  decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                  child: Column(
                    children: entry.value.map((item) {
                      final q = (item['q'] as Map)[locale] ?? (item['q'] as Map)['en'];
                      final a = (item['a'] as Map)[locale] ?? (item['a'] as Map)['en'];
                      return Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(q, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text(a, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                        ]),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
