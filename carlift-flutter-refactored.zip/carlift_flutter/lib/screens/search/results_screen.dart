import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import '../schedule/schedule_screen.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final search = context.watch<SearchProvider>();
    final favorites = context.watch<FavoritesProvider>();
    final q = search.query;

    return Scaffold(
      appBar: AppBar(title: Text(t.resultsTitle)),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: AppColors.navySoft,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RouteBadge(from: q.origin, to: q.destination, light: true),
                const SizedBox(height: 4),
                if (search.loading)
                  const Text('…', style: TextStyle(color: Color(0xFFB9C6CC), fontSize: 12))
                else
                  Text(t.matchingResultsCount(search.results.length), style: const TextStyle(color: Color(0xFFB9C6CC), fontSize: 12)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              SelectPill(label: t.sortEarliest, active: true, onTap: () => context.read<SearchProvider>().sortByTime()),
              const SizedBox(width: 8),
              SelectPill(label: t.sortCheapest, active: false, onTap: () => context.read<SearchProvider>().sortByPrice()),
            ]),
          ),
          Expanded(
            child: search.loading
                ? const LoadingView()
                : search.results.isEmpty
                    ? _EmptyResults(t: t)
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        itemCount: search.results.length + 1, // +1 to slot in an ad after the first result
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (context, i) {
                          if (i == 1) return const AdBannerWidget(placementZone: 'search_results');
                          final idx = i > 1 ? i - 1 : i;
                          final ride = search.results[idx];
                          return _RideCard(
                            ride: ride,
                            isFav: favorites.isFavorite(ride),
                            onToggleFav: () => context.read<FavoritesProvider>().toggle(ride),
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ScheduleScreen(ride: ride))),
                            t: t,
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

class _EmptyResults extends StatelessWidget {
  final AppLocalizations t;
  const _EmptyResults({required this.t});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.search_off_rounded, size: 32, color: AppColors.muted),
          const SizedBox(height: 12),
          Text(t.noResults, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.text)),
          const SizedBox(height: 4),
          Text(t.noResultsSubtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]),
      ),
    );
  }
}

class _RideCard extends StatelessWidget {
  final RideOption ride;
  final bool isFav;
  final VoidCallback onToggleFav;
  final VoidCallback onTap;
  final AppLocalizations t;
  const _RideCard({required this.ride, required this.isFav, required this.onToggleFav, required this.onTap, required this.t});

  @override
  Widget build(BuildContext context) {
    final lowSeats = ride.seatsLeft <= 3;
    final timeLabel = TimeOfDay.fromDateTime(ride.departureTime).format(context);
    return Stack(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.line)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  CircleAvatar(radius: 18, backgroundColor: hexToColor(ride.colorHex), child: Text(ride.initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(ride.company, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      Row(children: [const Icon(Icons.star_rounded, size: 14, color: AppColors.gold), Text(' ${ride.rating}', style: const TextStyle(fontSize: 11, color: AppColors.muted))]),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 28),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text(timeLabel, style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.navy)),
                      Text('${ride.durationMinutes} ${t.minutes}', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  const Icon(Icons.location_on_rounded, size: 12, color: AppColors.muted),
                  const SizedBox(width: 4),
                  Expanded(child: Text(ride.stops.join('  ·  '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppColors.muted))),
                ]),
                const Divider(height: 20),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: lowSeats ? AppColors.brickTint : AppColors.tealTint, borderRadius: BorderRadius.circular(999)),
                    child: Text('${ride.seatsLeft} ${t.seatsLeft}', style: TextStyle(fontSize: 11, color: lowSeats ? AppColors.brick : AppColors.teal)),
                  ),
                  RichText(text: TextSpan(children: [
                    TextSpan(text: 'AED ${ride.priceDaily.toStringAsFixed(0)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.navy)),
                    TextSpan(text: ' ${t.perDay}', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                  ])),
                ]),
              ],
            ),
          ),
        ),
        Positioned(
          top: 10, right: 10,
          child: IconButton(
            onPressed: onToggleFav,
            icon: Icon(isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFav ? AppColors.brick : AppColors.muted, size: 20),
          ),
        ),
      ],
    );
  }
}
