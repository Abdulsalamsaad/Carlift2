import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import 'results_screen.dart';

class FlightSearchScreen extends StatefulWidget {
  const FlightSearchScreen({super.key});
  @override
  State<FlightSearchScreen> createState() => _FlightSearchScreenState();
}

class _FlightSearchScreenState extends State<FlightSearchScreen> {
  String? _openPicker; // 'origin' | 'destination' | null
  TimeOfDay _time = const TimeOfDay(hour: 7, minute: 15);
  String _frequency = 'monthly';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<SearchProvider>().loadZones());
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _time);
    if (picked != null) setState(() => _time = picked);
  }

  void _swap() {
    final search = context.read<SearchProvider>();
    final q = search.query;
    search.updateQuery(q.copyWith(origin: q.destination, destination: q.origin));
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final search = context.watch<SearchProvider>();
    final auth = context.watch<AuthProvider>();
    final unread = context.watch<NotificationsProvider>().unreadCount;
    final q = search.query;
    final sameZone = q.origin == q.destination;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: Responsive.contentMaxWidth(context)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
                    decoration: const BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.only(bottomLeft: Radius.circular(28), bottomRight: Radius.circular(28))),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(t.appTitle.toUpperCase(), style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w600, fontSize: 13, letterSpacing: 1)),
                              const SizedBox(height: 6),
                              Text('${t.tagline}${auth.user != null ? ", ${auth.user!.name.split(' ').first}" : ''}',
                                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800, height: 1.2)),
                            ],
                          ),
                        ),
                        _NotificationBell(unread: unread),
                      ],
                    ),
                  ),

                  Transform.translate(
                    offset: const Offset(0, -20),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 16, offset: Offset(0, 6))]),
                        child: Column(
                          children: [
                            _zoneRow(
                              icon: Icons.trip_origin_rounded, iconBg: AppColors.tealTint, iconColor: AppColors.teal,
                              label: t.origin, value: q.origin,
                              onTap: () => setState(() => _openPicker = _openPicker == 'origin' ? null : 'origin'),
                            ),
                            Row(children: [
                              const SizedBox(width: 16, child: Divider()),
                              const Spacer(),
                              InkWell(
                                onTap: _swap, borderRadius: BorderRadius.circular(999),
                                child: Container(margin: const EdgeInsets.symmetric(vertical: 4), padding: const EdgeInsets.all(6),
                                    decoration: const BoxDecoration(color: AppColors.sand, shape: BoxShape.circle),
                                    child: const Icon(Icons.swap_vert_rounded, size: 16, color: AppColors.navy)),
                              ),
                            ]),
                            _zoneRow(
                              icon: Icons.location_on_rounded, iconBg: AppColors.goldTint, iconColor: AppColors.goldDeep,
                              label: t.destination, value: q.destination,
                              onTap: () => setState(() => _openPicker = _openPicker == 'destination' ? null : 'destination'),
                            ),
                            if (_openPicker != null) ...[
                              const Divider(height: 20),
                              Wrap(
                                spacing: 8, runSpacing: 8,
                                children: (_openPicker == 'origin' ? search.pickupZones : search.destinationZones).map((z) {
                                  final active = (_openPicker == 'origin' ? q.origin : q.destination) == z;
                                  return SelectPill(label: z, active: active, onTap: () {
                                    search.updateQuery(_openPicker == 'origin' ? q.copyWith(origin: z) : q.copyWith(destination: z));
                                    setState(() => _openPicker = null);
                                  });
                                }).toList(),
                              ),
                            ],
                            const Divider(height: 24),
                            // Exact departure time — flight-style, down to the minute
                            InkWell(
                              onTap: _pickTime,
                              child: Row(children: [
                                const Icon(Icons.access_time_rounded, size: 16, color: AppColors.muted),
                                const SizedBox(width: 8),
                                Text('${t.departureTime}: ', style: const TextStyle(fontSize: 13, color: AppColors.muted)),
                                Text(_time.format(context), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.navy, fontFamily: 'monospace')),
                                const Spacer(),
                                const Icon(Icons.chevron_right_rounded, size: 16, color: AppColors.muted),
                              ]),
                            ),
                            const SizedBox(height: 12),
                            // Frequency / pricing tier selector
                            Text(t.frequency, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Expanded(child: _freqChip(t.daily, 'daily')),
                                const SizedBox(width: 8),
                                Expanded(child: _freqChip(t.weekly, 'weekly')),
                                const SizedBox(width: 8),
                                Expanded(child: _freqChip(t.monthly, 'monthly')),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.search_rounded, size: 18),
                            label: Text(t.searchButton),
                            onPressed: sameZone ? null : () async {
                              final now = DateTime.now();
                              search.updateQuery(q.copyWith(
                                departureTime: DateTime(now.year, now.month, now.day, _time.hour, _time.minute),
                                frequency: _frequency,
                              ));
                              await search.search();
                              if (context.mounted) {
                                Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ResultsScreen()));
                              }
                            },
                          ),
                        ),
                        if (sameZone) Padding(padding: const EdgeInsets.only(top: 8), child: Text(t.zonesSameError, style: const TextStyle(color: AppColors.brick, fontSize: 11))),
                        const SizedBox(height: 16),
                        const AdBannerWidget(placementZone: 'home_hero'),
                        const SizedBox(height: 16),
                        Row(children: [
                          const Icon(Icons.verified_rounded, size: 14, color: AppColors.teal),
                          const SizedBox(width: 6),
                          Expanded(child: Text(t.verifiedCompanies, style: const TextStyle(fontSize: 12, color: AppColors.muted))),
                        ]),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: MarqueeTicker(text: t.partnerTickerText),
    );
  }

  Widget _freqChip(String label, String value) {
    final active = _frequency == value;
    return InkWell(
      onTap: () => setState(() => _frequency = value),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? AppColors.navy : AppColors.sand,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.muted)),
      ),
    );
  }

  Widget _zoneRow({required IconData icon, required Color iconBg, required Color iconColor, required String label, required String value, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(children: [
          Container(width: 32, height: 32, decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle), child: Icon(icon, size: 16, color: iconColor)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted, letterSpacing: 0.5)),
              Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.text)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _NotificationBell extends StatelessWidget {
  final int unread;
  const _NotificationBell({required this.unread});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).pushNamed('/notifications'),
      borderRadius: BorderRadius.circular(999),
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), shape: BoxShape.circle),
        child: Stack(
          alignment: Alignment.center,
          children: [
            const Icon(Icons.notifications_rounded, color: Colors.white, size: 18),
            if (unread > 0)
              Positioned(
                top: 6, right: 6,
                child: Container(
                  padding: const EdgeInsets.all(3),
                  decoration: const BoxDecoration(color: AppColors.brick, shape: BoxShape.circle),
                  constraints: const BoxConstraints(minWidth: 14, minHeight: 14),
                  child: Text('$unread', style: const TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
