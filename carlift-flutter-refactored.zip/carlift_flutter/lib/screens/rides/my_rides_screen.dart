import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import 'pass_detail_screen.dart';

class MyRidesScreen extends StatefulWidget {
  const MyRidesScreen({super.key});
  @override
  State<MyRidesScreen> createState() => _MyRidesScreenState();
}

class _MyRidesScreenState extends State<MyRidesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<BookingProvider>().load());
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final booking = context.watch<BookingProvider>();

    if (booking.loading && booking.subscriptions.isEmpty) return const LoadingView();

    if (booking.subscriptions.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 64, height: 64, decoration: const BoxDecoration(color: AppColors.tealTint, shape: BoxShape.circle), child: const Icon(Icons.confirmation_num_rounded, color: AppColors.teal, size: 26)),
            const SizedBox(height: 16),
            Text(t.noRidesTitle, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
            const SizedBox(height: 4),
            Text(t.noRidesSubtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          ]),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => context.read<BookingProvider>().load(),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: booking.subscriptions.map((s) => _RideRow(sub: s, t: t)).toList(),
      ),
    );
  }
}

class _RideRow extends StatelessWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _RideRow({required this.sub, required this.t});

  @override
  Widget build(BuildContext context) {
    final cancelled = sub.status != 'active';
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Opacity(
        opacity: cancelled ? 0.6 : 1,
        child: InkWell(
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PassDetailScreen(subscriptionId: sub.id))),
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(18)),
            child: Row(children: [
              CircleAvatar(radius: 20, backgroundColor: hexToColor(sub.colorHex), child: Text(sub.initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  RouteBadge(from: sub.origin, to: sub.destination),
                  const SizedBox(height: 2),
                  Text('${sub.company} · ${sub.plan}', style: const TextStyle(fontSize: 11, color: AppColors.muted)),
                ]),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: cancelled ? const Color(0xFFF0F0F0) : AppColors.tealTint, borderRadius: BorderRadius.circular(999)),
                child: Text(cancelled ? t.cancelledStatus : t.activeStatus, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: cancelled ? AppColors.muted : AppColors.teal)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
