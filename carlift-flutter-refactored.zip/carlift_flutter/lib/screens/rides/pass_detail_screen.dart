import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';

class PassDetailScreen extends StatelessWidget {
  final String subscriptionId;
  const PassDetailScreen({super.key, required this.subscriptionId});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final booking = context.watch<BookingProvider>();
    final sub = booking.subscriptions.where((s) => s.id == subscriptionId).firstOrNull;

    if (sub == null) return Scaffold(appBar: AppBar(title: Text(t.myPassTitle)), body: const LoadingView());

    return Scaffold(
      appBar: AppBar(title: Text(t.myPassTitle)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _BoardingPass(sub: sub, t: t),
          const SizedBox(height: 16),
          _DriverCard(sub: sub, t: t),
          if (sub.status == 'active') ...[
            const SizedBox(height: 16),
            _LiveTrackerCard(sub: sub, t: t),
            const SizedBox(height: 16),
            _CancelCard(sub: sub, t: t),
          ],
        ],
      ),
    );
  }
}

class _BoardingPass extends StatelessWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _BoardingPass({required this.sub, required this.t});

  @override
  Widget build(BuildContext context) {
    final active = sub.status == 'active';
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 14, offset: Offset(0, 6))]),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(sub.company.toUpperCase(), style: const TextStyle(color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)),
              const SizedBox(height: 6),
              RouteBadge(from: sub.origin, to: sub.destination, light: true, fontSize: 20),
            ]),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: active ? const Color(0xFF1E4D3A) : const Color(0xFF3A2222), borderRadius: BorderRadius.circular(999)),
              child: Text(active ? '● ${t.activeStatus}' : t.cancelledStatus, style: TextStyle(color: active ? const Color(0xFF7BDDAA) : const Color(0xFFE29B9B), fontSize: 10, fontWeight: FontWeight.bold)),
            ),
          ]),
        ),
        SizedBox(height: 12, child: CustomPaint(painter: _DashPainter(), size: Size.infinite)),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Row(children: [
            Expanded(child: _stat(t.plan, sub.plan.toUpperCase())),
            Expanded(child: _stat(t.days, sub.days.join(' '))),
            Expanded(child: _stat(t.departs, sub.departureLabel, mono: true)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Row(children: List.generate(28, (i) => Expanded(child: Container(height: 22, color: i % 2 == 0 ? Colors.white : Colors.transparent)))),
        ),
      ]),
    );
  }

  Widget _stat(String label, String value, {bool mono = false}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 9, color: Color(0xFF8FA3AB))),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white, fontFamily: mono ? 'monospace' : null)),
      ]);
}

class _DashPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.25)..strokeWidth = 1;
    double x = 8;
    while (x < size.width - 8) {
      canvas.drawLine(Offset(x, size.height / 2), Offset(x + 5, size.height / 2), paint);
      x += 10;
    }
    final notch = Paint()..color = AppColors.sand;
    canvas.drawCircle(Offset(0, size.height / 2), 8, notch);
    canvas.drawCircle(Offset(size.width, size.height / 2), 8, notch);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _DriverCard extends StatelessWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _DriverCard({required this.sub, required this.t});

  Future<void> _call() async {
    final uri = Uri(scheme: 'tel', path: sub.driverPhone.replaceAll(' ', ''));
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _message(BuildContext context) async {
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (_) => _ChatSheet(sub: sub, t: t),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(18)),
      child: Row(children: [
        CircleAvatar(radius: 22, backgroundColor: hexToColor(sub.colorHex), child: Text(sub.initials, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${sub.driverName} · ${t.driver}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            Text('Bus ${zoneCode(sub.origin)}${sub.busNumber}', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
        _iconCircle(Icons.call_rounded, _call),
        const SizedBox(width: 8),
        _iconCircle(Icons.chat_bubble_rounded, () => _message(context), badge: sub.messages.where((m) => m.from == 'driver').isNotEmpty),
      ]),
    );
  }

  Widget _iconCircle(IconData icon, VoidCallback onTap, {bool badge = false}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Stack(children: [
          Container(width: 36, height: 36, decoration: const BoxDecoration(color: AppColors.tealTint, shape: BoxShape.circle), child: Icon(icon, size: 16, color: AppColors.teal)),
          if (badge) Positioned(top: 0, right: 0, child: Container(width: 9, height: 9, decoration: const BoxDecoration(color: AppColors.brick, shape: BoxShape.circle))),
        ]),
      );
}

class _ChatSheet extends StatefulWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _ChatSheet({required this.sub, required this.t});
  @override
  State<_ChatSheet> createState() => _ChatSheetState();
}

class _ChatSheetState extends State<_ChatSheet> {
  final _controller = TextEditingController();
  bool _sending = false;

  Future<void> _send() async {
    if (_controller.text.trim().isEmpty) return;
    final text = _controller.text.trim();
    _controller.clear();
    setState(() => _sending = true);
    await context.read<BookingProvider>().sendMessage(widget.sub.id, text);
    setState(() => _sending = false);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BookingProvider>(builder: (context, booking, _) {
      final sub = booking.subscriptions.where((s) => s.id == widget.sub.id).firstOrNull ?? widget.sub;
      return Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.7,
          decoration: const BoxDecoration(color: AppColors.sand, borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
          child: Column(children: [
            Padding(padding: const EdgeInsets.all(14), child: Text(sub.driverName, style: const TextStyle(fontWeight: FontWeight.w700))),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                children: sub.messages.map((m) {
                  final mine = m.from == 'me';
                  return Align(
                    alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
                      decoration: BoxDecoration(
                        color: mine ? AppColors.navy : Colors.white,
                        border: mine ? null : Border.all(color: AppColors.line),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(m.text, style: TextStyle(color: mine ? Colors.white : AppColors.text, fontSize: 13)),
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(child: TextField(controller: _controller, decoration: const InputDecoration(hintText: '…'), onSubmitted: (_) => _send())),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _sending ? null : _send, icon: const Icon(Icons.send_rounded), style: IconButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: AppColors.navy)),
              ]),
            ),
          ]),
        ),
      );
    });
  }
}

/// Live tracker — CustomPaint-based animated placeholder. This is the
/// integration point for a real map: swap this widget's body for
/// GoogleMap/MapWidget (google_maps_flutter / mapbox_maps_flutter) and feed
/// the marker position from your live-location stream (websocket/polling
/// against a GET /api/trips/:id/location endpoint).
class _LiveTrackerCard extends StatefulWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _LiveTrackerCard({required this.sub, required this.t});
  @override
  State<_LiveTrackerCard> createState() => _LiveTrackerCardState();
}

class _LiveTrackerCardState extends State<_LiveTrackerCard> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = hexToColor(widget.sub.colorHex);
    return Container(
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(widget.t.liveTracker, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.tealTint, borderRadius: BorderRadius.circular(999)),
              child: Text(widget.t.arrivingIn(6), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.teal)),
            ),
          ]),
        ),
        Container(
          height: 160,
          margin: const EdgeInsets.symmetric(horizontal: 16),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: const Color(0xFFDCE7E5), borderRadius: BorderRadius.circular(14)),
          child: Stack(children: [
            CustomPaint(size: Size.infinite, painter: _GridPainter()),
            CustomPaint(size: Size.infinite, painter: _RoutePainter(color: accent)),
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) => Align(alignment: Alignment(-0.85 + _controller.value * 1.7, -0.05), child: child),
              child: Container(
                width: 30, height: 30,
                decoration: BoxDecoration(color: accent, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2), boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))]),
                child: const Icon(Icons.directions_bus_rounded, size: 15, color: Colors.white),
              ),
            ),
            Positioned(
              bottom: 8, right: 8,
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: Colors.white.withOpacity(0.85), borderRadius: BorderRadius.circular(999)),
                  child: const Text('Live · Mapbox', style: TextStyle(fontSize: 10, color: AppColors.muted))),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Row(children: [const Icon(Icons.location_on_rounded, size: 13, color: AppColors.muted), const SizedBox(width: 6), Text(widget.t.stopsAway(3), style: const TextStyle(fontSize: 12, color: AppColors.muted))]),
            Row(children: [const Icon(Icons.people_alt_rounded, size: 13, color: AppColors.muted), const SizedBox(width: 6), Text(widget.t.seatsFilled(4, 14), style: const TextStyle(fontSize: 12, color: AppColors.muted))]),
          ]),
        ),
      ]),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFC7D6D3)..strokeWidth = 1;
    for (int i = 0; i < 6; i++) {
      final x = size.width * (i * 0.18 + 0.05);
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (int i = 0; i < 4; i++) {
      final y = size.height * (i * 0.3 + 0.1);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _RoutePainter extends CustomPainter {
  final Color color;
  _RoutePainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color.withOpacity(0.8)..strokeWidth = 3..style = PaintingStyle.stroke;
    final path = Path()..moveTo(size.width * 0.05, size.height * 0.75)..quadraticBezierTo(size.width * 0.3, size.height * 0.1, size.width * 0.9, size.height * 0.65);
    canvas.drawPath(_dash(path, 6, 6), paint);
  }

  Path _dash(Path source, double dashWidth, double gapWidth) {
    final dest = Path();
    for (final metric in source.computeMetrics()) {
      double distance = 0;
      while (distance < metric.length) {
        dest.addPath(metric.extractPath(distance, distance + dashWidth), Offset.zero);
        distance += dashWidth + gapWidth;
      }
    }
    return dest;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CancelCard extends StatefulWidget {
  final Subscription sub;
  final AppLocalizations t;
  const _CancelCard({required this.sub, required this.t});
  @override
  State<_CancelCard> createState() => _CancelCardState();
}

class _CancelCardState extends State<_CancelCard> {
  bool _confirming = false;
  bool _cancelling = false;

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(18)),
      child: !_confirming
          ? TextButton.icon(
              onPressed: () => setState(() => _confirming = true),
              icon: const Icon(Icons.delete_outline_rounded, color: AppColors.brick, size: 16),
              label: Text(t.cancelRide, style: const TextStyle(color: AppColors.brick, fontWeight: FontWeight.w600, fontSize: 13)),
            )
          : Column(children: [
              Text(t.confirmCancel(widget.sub.plan), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () => setState(() => _confirming = false), child: Text(t.keepPass))),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppColors.brick),
                    onPressed: _cancelling
                        ? null
                        : () async {
                            setState(() => _cancelling = true);
                            await context.read<BookingProvider>().cancel(widget.sub.id);
                            if (context.mounted) Navigator.of(context).pop();
                          },
                    child: Text(t.yesCancel),
                  ),
                ),
              ]),
            ]),
    );
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
