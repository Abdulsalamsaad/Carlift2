import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/models.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import '../checkout/checkout_screen.dart';

const _weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

class ScheduleScreen extends StatefulWidget {
  final RideOption ride;
  const ScheduleScreen({super.key, required this.ride});
  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  final config = ScheduleConfig();

  void _toggleDay(String d) {
    setState(() {
      config.days = config.days.contains(d) ? config.days.where((x) => x != d).toList() : [...config.days, d];
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final ride = widget.ride;
    final price = ride.priceForPlan(config.plan);
    final timeLabel = TimeOfDay.fromDateTime(ride.departureTime).format(context);

    return Scaffold(
      appBar: AppBar(title: Text(t.scheduleTitle)),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.line), borderRadius: BorderRadius.circular(16)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    RouteBadge(from: ride.originZone, to: ride.destinationZone),
                    const SizedBox(height: 6),
                    Text('${ride.company} · $timeLabel', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                  ]),
                ),
                const SizedBox(height: 20),
                Text(t.workingDays, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 8),
                Row(
                  children: _weekDays.map((d) {
                    final active = config.days.contains(d);
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: InkWell(
                          onTap: () => _toggleDay(d),
                          borderRadius: BorderRadius.circular(8),
                          child: Container(
                            height: 44, alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: active ? AppColors.teal : Colors.white,
                              border: Border.all(color: active ? AppColors.teal : AppColors.line),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(d, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: active ? Colors.white : AppColors.muted)),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                if (config.days.isEmpty)
                  Padding(padding: const EdgeInsets.only(top: 6), child: Text(t.pickAtLeastOneDay, style: const TextStyle(color: AppColors.brick, fontSize: 11))),
                TextButton(
                  onPressed: () => setState(() => config.days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']),
                  style: TextButton.styleFrom(padding: EdgeInsets.zero, alignment: Alignment.centerLeft),
                  child: Text(t.resetWeekdays, style: const TextStyle(color: AppColors.teal, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
                const SizedBox(height: 16),
                Text(t.shift, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: _ShiftCard(label: '${t.morningShift} · $timeLabel', tag: t.included, active: true)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: InkWell(
                      onTap: () => setState(() => config.roundTrip = !config.roundTrip),
                      child: _ShiftCard(label: '${t.eveningReturn} · 5:30 PM', tag: config.roundTrip ? t.added : t.addReturn, active: config.roundTrip),
                    ),
                  ),
                ]),
                const SizedBox(height: 16),
                Text(t.planLabel, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 8),
                _PlanOption(label: t.daily, note: t.payAsYouRide, price: ride.priceDaily, selected: config.plan == 'daily', onTap: () => setState(() => config.plan = 'daily')),
                const SizedBox(height: 8),
                _PlanOption(label: t.weekly, note: t.save7, price: ride.priceWeekly, selected: config.plan == 'weekly', onTap: () => setState(() => config.plan = 'weekly')),
                const SizedBox(height: 8),
                _PlanOption(label: t.monthly, note: t.bestValue, price: ride.priceMonthly, selected: config.plan == 'monthly', onTap: () => setState(() => config.plan = 'monthly')),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.line))),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: config.days.isEmpty ? null : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CheckoutScreen(ride: ride, config: config))),
                child: Text('${t.continueButton} · AED ${price.toStringAsFixed(0)}'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ShiftCard extends StatelessWidget {
  final String label;
  final String tag;
  final bool active;
  const _ShiftCard({required this.label, required this.tag, required this.active});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: active ? AppColors.tealTint : Colors.white, border: Border.all(color: active ? AppColors.teal : AppColors.line), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.access_time_rounded, size: 13, color: active ? AppColors.teal : AppColors.muted),
          const SizedBox(width: 4),
          Text(tag, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: active ? AppColors.teal : AppColors.muted)),
        ]),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _PlanOption extends StatelessWidget {
  final String label;
  final String note;
  final double price;
  final bool selected;
  final VoidCallback onTap;
  const _PlanOption({required this.label, required this.note, required this.price, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: selected ? AppColors.goldTint : Colors.white, border: Border.all(color: selected ? AppColors.gold : AppColors.line), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Icon(selected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: selected ? AppColors.gold : AppColors.line),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            Text(note, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          ])),
          Text('AED ${price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.navy)),
        ]),
      ),
    );
  }
}
