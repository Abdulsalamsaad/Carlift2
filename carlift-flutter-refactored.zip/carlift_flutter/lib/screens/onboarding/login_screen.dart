import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _submitting = false;
  String? _emailError, _passwordError, _formError;

  Future<void> _submit() async {
    final t = AppLocalizations.of(context)!;
    setState(() {
      _emailError = _email.text.trim().contains('@') ? null : t.errorRequired;
      _passwordError = _password.text.isNotEmpty ? null : t.errorRequired;
      _formError = null;
    });
    if (_emailError != null || _passwordError != null) return;

    setState(() => _submitting = true);
    final ok = await context.read<AuthProvider>().login(email: _email.text.trim(), password: _password.text);
    setState(() => _submitting = false);
    if (!ok && mounted) {
      setState(() => _formError = t.errorInvalidCredentials);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: Responsive.contentMaxWidth(context)),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('DUBAI CARLIFT', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w600, fontSize: 13, letterSpacing: 1)),
                  const SizedBox(height: 6),
                  Text(t.loginTitle, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        AppField(label: t.emailField, controller: _email, error: _emailError, keyboardType: TextInputType.emailAddress),
                        const SizedBox(height: 12),
                        AppField(label: t.passwordField, controller: _password, error: _passwordError, obscure: true),
                        if (_formError != null) ...[
                          const SizedBox(height: 8),
                          Text(_formError!, style: const TextStyle(color: AppColors.brick, fontSize: 12)),
                        ],
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _submitting ? null : _submit,
                            child: _submitting
                                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.navy))
                                : Text(t.loginButton),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: TextButton(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegisterScreen())),
                      child: Text.rich(TextSpan(
                        children: [
                          TextSpan(text: '${t.noAccountYet} ', style: const TextStyle(color: Color(0xFF8FA3AB), fontSize: 13)),
                          TextSpan(text: t.registerButton, style: const TextStyle(color: AppColors.gold, fontSize: 13, fontWeight: FontWeight.w600)),
                        ],
                      )),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
