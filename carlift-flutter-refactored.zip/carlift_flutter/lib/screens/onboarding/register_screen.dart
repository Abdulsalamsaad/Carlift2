import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../state/providers.dart';
import '../../widgets/shared_widgets.dart';
import '../../l10n/app_localizations.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _submitting = false;
  String? _nameErr, _phoneErr, _emailErr, _passErr, _formErr;

  Future<void> _submit() async {
    final t = AppLocalizations.of(context)!;
    setState(() {
      _nameErr = _name.text.trim().length >= 2 ? null : t.errorRequired;
      _phoneErr = _phone.text.replaceAll(RegExp(r'\D'), '').length >= 7 ? null : t.errorRequired;
      _emailErr = _email.text.trim().contains('@') ? null : t.errorRequired;
      _passErr = _password.text.length >= 8 ? null : t.errorRequired;
      _formErr = null;
    });
    if ([_nameErr, _phoneErr, _emailErr, _passErr].any((e) => e != null)) return;

    setState(() => _submitting = true);
    final ok = await context.read<AuthProvider>().register(
          name: _name.text.trim(), phone: _phone.text.trim(), email: _email.text.trim(), password: _password.text,
        );
    setState(() => _submitting = false);
    if (ok && mounted) Navigator.of(context).pop();
    if (!ok && mounted) setState(() => _formErr = t.errorGeneric);
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(backgroundColor: AppColors.navy, elevation: 0),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: Responsive.contentMaxWidth(context)),
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.registerTitle, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        AppField(label: t.fullName, controller: _name, error: _nameErr),
                        const SizedBox(height: 12),
                        AppField(label: t.phoneNumber, controller: _phone, error: _phoneErr, keyboardType: TextInputType.phone),
                        const SizedBox(height: 12),
                        AppField(label: t.emailField, controller: _email, error: _emailErr, keyboardType: TextInputType.emailAddress),
                        const SizedBox(height: 12),
                        AppField(label: t.passwordField, controller: _password, error: _passErr, obscure: true),
                        if (_formErr != null) ...[
                          const SizedBox(height: 8),
                          Text(_formErr!, style: const TextStyle(color: AppColors.brick, fontSize: 12)),
                        ],
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _submitting ? null : _submit,
                            child: _submitting
                                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.navy))
                                : Text(t.registerButton),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
