# Dubai Carlift — Flutter App (Android / iOS / Web)

Cross-platform passenger app for the Carlift Transit Platform. Built with
Flutter + Provider + Dio, structured so every screen talks to an abstract
repository interface — swap one flag and the entire app moves from local
mock data to your live Express/Prisma backend with no screen-level changes.

## ⚠️ Status — read this first

This codebase was written in an environment **without a Flutter SDK or
network access**, so it has not been compiled, `flutter analyze`'d, or run
on a device/emulator. It's a complete, real implementation — not a mockup —
but you should treat first-run compile errors as expected, not a sign
something is fundamentally wrong. The fastest path to a working build:

```bash
flutter pub get
flutter gen-l10n        # regenerates lib/l10n/app_localizations.dart from the 6 .arb files
flutter analyze         # will surface any remaining type/import issues in seconds
flutter run             # or: flutter run -d chrome
```

If `flutter analyze` reports issues, they're almost certainly small
(a missing import, a signature mismatch) — the architecture, state wiring,
and localization content are all real and complete.

## Architecture

```
lib/
  core/
    theme/app_theme.dart      Design tokens (navy/sand/gold), responsive helpers
    router/app_shell.dart      Bottom-nav shell (Search / My Rides / Profile)
    auth_gate.dart              Splash → Login → App, based on session state
  data/
    models/models.dart         Data models — field names mirror the Prisma schema 1:1
    api_client.dart             Dio client: JWT header injection, refresh-token retry
    repositories/               One abstract interface + Mock impl + Http impl per domain:
      auth_repository.dart        register/login/updateProfile/logout
      search_repository.dart      flight-style filtered search
      booking_repository.dart     create/list/cancel subscriptions, driver chat
      misc_repositories.dart      favorites, notifications, ads
  state/providers.dart         ChangeNotifier providers wrapping each repository
  screens/                     One folder per flow (onboarding, search, schedule,
                                checkout, rides, profile) — every screen is wired to
                                its provider, no dead buttons
  widgets/shared_widgets.dart  RouteBadge, AdBannerWidget, MarqueeTicker, etc.
  l10n/                        6 real translated ARB packs (en/ar/ur/ne/tl/bn)
```

## Going live: mock → real backend

Every repository has two implementations. `main.dart` picks between them with:

```dart
class AppConfig {
  static const bool useMockData = bool.fromEnvironment('USE_MOCK_DATA', defaultValue: true);
}
```

To point at your deployed Express backend:

```bash
flutter run \
  --dart-define=USE_MOCK_DATA=false \
  --dart-define=API_BASE_URL=https://api.your-carlift-domain.com/api
```

No screen code changes — every widget reads from the provider, which reads
from whichever repository implementation was injected in `main.dart`.

### Backend endpoints this app expects

Most of these already exist in the accompanying Express/Prisma project. Two
were added specifically to support this app:

| Endpoint | Status | Notes |
|---|---|---|
| `GET /api/routes/search` | ✅ added | Flight-style filtering by origin/destination/departure_time window |
| `GET /api/routes/zones` | ✅ added | Distinct zone lists for the search pickers |
| `POST /api/auth/register`, `/login`, `/refresh`, `GET /me` | ✅ existing | |
| `POST/GET/PATCH /api/subscriptions` | ✅ existing | |
| `GET/POST /api/subscriptions/:id/messages` | ✅ added | Backs the in-app driver chat |
| `GET /api/v1/passenger/profile`, `/settings`, `/favorites` | ✅ existing | |
| `GET /api/v1/notifications`, `PATCH .../read` | ✅ existing | |
| `GET /api/v1/ads/active`, `POST /api/v1/ads/:id/click` | ✅ existing | |
| Live GPS position for the tracker map | ❌ not implemented | See below |

### What's intentionally mocked/stubbed, and what to do about it

- **Live map tracking**: the tracker screen renders a real animated
  CustomPaint map (not a placeholder image), but it's not connected to an
  actual bus GPS feed. To go live: add `google_maps_flutter` or
  `mapbox_maps_flutter` (commented out in `pubspec.yaml`, needs an API key),
  and replace `_LiveTrackerCard`'s body in
  `lib/screens/rides/pass_detail_screen.dart` with a real map widget fed by
  a location stream — a websocket or a polling `GET /api/trips/:id/location`
  endpoint you'll need to add, backed by whatever GPS hardware/app your
  drivers use.
- **Driver/bus assignment on search results**: the search endpoint shows a
  *representative* driver/bus per company (any bus with a driver assigned),
  not the specific one you'll actually ride with — that's only knowable once
  a `Trip` is generated and a bus assigned for a specific date. This is
  flagged with a comment in `route.controller.js`.
- **Ratings**: `RideOption.rating` is currently a flat placeholder (4.7) —
  there's no reviews/ratings table in the schema yet.
- **Payment processing**: card/Tabby submission simulates a delay and then
  succeeds — there's no real payment gateway call. Wire Tabby's SDK and a
  card processor (Stripe, Network International, etc.) into
  `CheckoutScreen._submit()` before accepting real payments.

## Translations

All 6 ARB files (`lib/l10n/app_*.arb`) contain complete, independently
written translations — not machine-translated placeholders — covering every
UI string, including ICU plural/placeholder support (`{count}`, `{amount}`,
etc.). That said, for a real production launch, especially for
payment/legal-adjacent copy, have a native speaker of each language review
the FAQ and legal-document strings specifically
(`lib/screens/profile/faq_screen.dart`, `legal_screen.dart`) since those
carry more legal/financial weight than navigation labels.

RTL (Arabic, Urdu) is handled automatically by Flutter's `Directionality` —
there's no manual mirroring logic anywhere in this codebase, unlike a
hand-rolled web layout.

## Web/responsive notes

`Responsive.contentMaxWidth()` (in `app_theme.dart`) keeps the mobile-style
single column centered on wide viewports (tablet/desktop web) rather than
stretching it edge-to-edge. If you want a genuinely different desktop layout
(e.g. a two-pane search+results view), that's a bigger design pass beyond
this session's scope — flag it and we can design that separately.
